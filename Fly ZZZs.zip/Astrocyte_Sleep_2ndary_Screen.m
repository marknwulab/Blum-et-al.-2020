
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: 
% Analysis of Drosophila sleep parameters for RNAi screening of Glial
% Activation
% Input is a single folder containing only DAMfile scan produced activity
% files in 1-min bins, starting at 10AM (ZT0,lights on) of the day after
% loading (but these parameters can be changed below)
% 
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% To Do for Code
% to be done
%   day/night and daily total activity time in minutes across days and genotype 
%     (important if we care about arousal, might add this later)
%   day/night activity/sleep bout count and mean bout duration across days
%       and genotype (consider plotting this as a count nos vs bout length
%       using both colour and shape to distinguish individuals)
%   day/night brief awakenings (how is this defined?) 
%       Brief awakenings refers to 5-min periods with four or fewer activity counts that were
%       preceded and succeeded by a minimum of 5?minutes of inactivity (Koh Sehgal PNAS 2006)
%       Plot as histograms for sleep/activity bout length distributions
%   Calculate sleep rebound as the increase in total sleep (Zt0-6) (or adjusted for pulses)  after deprivation
%       minus normal sleep amount during that same time period the day before
%       deprivation
%   Use paddingzeros code so that incomplete files can be used to look at
%   data prior to termination of the experiment
%   


%  to be considered:
%   -Sleep consolidation curve = determine total sleep time as a function of the sleep definition (in minutes)
%   -Zscore sleep data (TST, Rebound, etc.) to ID outliers for screen
%   (might consider doing ICA for cluster analysis across all variables, maybe too hibrow?)
%   -Write code to identify outliers by name/line number and output to file for
%       easy vial trashing/selection based on criteria list

close all;
clear all;
addpath('C:\Users\ian_d\Documents\matlab\Circadian Scripts and Functions\Drosophila\Fly ZZZs')
tic
%% variables
%Nos of animals used for each line of the screen, either as a single number
%for evenly sized groups or vector with individual groupsizes 
%eg. groupnos=[x,y,z,aa,etc.]. Use NaN if all animals are in the same group. If no input is provided([]), prompts appear.
groupnos=[16];
C='C';E='E';grouptype=[]; %similarly this is a cell where E=experimental and
% C=control groups eg. ={C,C,E,E}, leave blank([]) to ignore deprivation
% thresholding for all groups
numperline=tknumberperline(groupnos);

% Variables which define what days of data to use. i.e. Since the screen is
% five days long and each trace will start at 10AM the day after load.
first=1; %delete these if you would rather answer a prompt each time
last=6;
actthresh=50; %threshold number of activity counts observed during the last 24hr of recording to ID dead animals.

sam=1; % input the sampling rate (time of each sample bin in minutes)
sr = 60/sam*24;

%Defining the x-axis for traces (in days)
be=1;
End=last-first+1;
Days=linspace(be,End,End);

%Prompts for type of analysis

Graphprompt = 'Would you like to (A)nalyze or just (V)isualize? (A/V) [A]: ';
%Analysis will automatically remove dead animals, Visualize will prompt.
GRAPH=input(Graphprompt, 's');
if isempty(GRAPH)
    GRAPH = 'A';
end

Allprompt = 'Apply activity thresholding to remove dead animals (Y)? [Y]';
%Analysis will automatically remove dead animals, Visualize will prompt.
ALL=input(Allprompt, 's');
if isempty(ALL)
    ALL = 'Y';
end

DDprompt = 'Is there any data in constant darkness? (Y/N) [N]: ';
DD=input(DDprompt, 's');
if isempty(DD)
    DD = 'N';
end

Depprompt = 'Is there a heat pulse ? (Y/N) [Y]: ';
DEP=input(Depprompt, 's');
if isempty(DEP)
    DEP = 'Y';
end

if strcmpi(DEP,'Y') == 1;
pulseprompt = 'Is it a daytime pulse (starting at ZT0)? (Y/N) [Y]: ';
PULSE=input(pulseprompt, 's');
    if isempty(PULSE)
    PULSE = 'Y';
    end
end

if strcmpi(DEP,'Y') == 1;
overnightprompt = 'Is there a second heat pulse at the end of the experiment? (Y/N) [Y]: ';
PULSE2=input(overnightprompt, 's');
    if isempty(PULSE2)
    PULSE2 = 'Y';
    end
end

% Sleep Variables
LDday=2; %specify which day of LD to analyze for sleep measures (from start of trace, not experiment)
sleepdef=5; %nos of minutes with no activity to be counted as sleep
sleepbin=30; %size of sleep binning (in minutes)
sleepsr=60/sleepbin*24;

%variables for sleep analysis in LD and DD
if strcmpi(DD,'Y') == 1;
daysLD=2; %nos of days of L:D prior to D:D (assumes data begins at ZT0)
DDday=4; %specify which day of DD to analyze for sleep measures
else
daysLD=End;
end

%variables for sleep analysis with deprivation
if strcmpi(DEP,'Y') == 1
Depstart=2.5; %start of sleep deprivation period in days (N.B. first day of recording is day 1)
Depend=3; %end of sleep deprivation period in days   
depday=floor(Depstart);
baseday=depday-1;
recoday=depday+1;
depthresh=98; %defines the deprivation threshold for retaining flies for analysis (%)
recobin=6; %defines the timespan (in hours from ZT0) used for recovery analysis.
end
if strcmpi(PULSE,'Y') == 1
pulse=1; %length of pulse (h)
Depstart=3.5
; %start of sleep deprivation pulse in days (N.B. first day of recording is day 1)
Depend=Depstart + pulse/24; %end of sleep deprivation period in days   
depday=floor(Depstart);
baseday=depday-1;
recoday=depday+1;
depthresh=0; %defines the deprivation threshold for retaining flies for analysis (%)
recobinpulse=4; %defines the timespan (in hours from end of pulse) used for recovery analysis.
end
if strcmpi(PULSE2,'Y') == 1
nightpulsestart=6.5;
nightpulseend=7;
nightpulseday=floor(nightpulsestart);
end


save('Variables.mat', '-mat');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Generate only sleep traces for quick visualization without quantitation
if strcmpi(GRAPH,'V') == 1;
    if exist('file_variables.mat','file')~=2
        tkfileload;
        tksleeptrace;
    elseif strcmpi(ALL,'N') == 1;
        tkfileload;
        tksleeptrace;
    else
        tksleeptrace;    
    end
end
%% Sleep analysis
if strcmpi(GRAPH,'A') == 1
    tkfileload;
    if strcmpi(DEP,'Y') == 1
        tksleepdep_parfor;
% %         tkzscore;
        tkanova;
    end
    %% Creating excel file with sleep data
    tkwritesleepdata;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% save('Screen_Variables.mat', '-mat'); % can use this to save any output
% variables from individual functions or scripts called but it is currently
% identical to variables.mat
toc
clear all;