%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: 
% Analysis of Drosophila Arousal Thresholding 
% Input is a single folder containing only DAMfile scan produced activity
% files in 1-min bins, starting at ZT0 (lights on) of the day after
% loading (but these parameters can be changed below).
% This code is adapted from the arousal thresholding protocol established in Wu et
% al., 2008 - "A genetic screen for sleep and circadian mutants reveals 
% mechanisms underlying regulation of sleep in Drosophila". A similar
% protocol was used in Liu et al., 2016 - Cell and Tabuchi et al., 2018 - Cell.
% 
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C) Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% To Do for Code
% -Allow user to enter the day of arousal thresholding
% -Use tkfileload to get the sleep data into the code
% -Prompt for array that lists the hours of that day during which there
% were pulses
% -Consider writing code that allows the pre-shaking criterion to be
% manipulated as Masashi suggested he got better results when using 5-15
% minutes of inactivity as his criterion.
% -Mark's original paper used activity in the following 2 minutes for his
% arousals, Sha used 3 min, and Masashi also used 3 min. Consider also
% making this a prompted variable.
%%
close all;
clear all;
addpath('C:\Users\ian_d\Documents\matlab\Circadian Scripts and Functions\Drosophila\arousal_threshold.m');
tic
%% variables
%Nos of animals used for each line of the screen, either as a single number
%for evenly sized groups or vector with individual groupsizes 
%eg. groupnos=[x,y,z,aa,etc.]. Use NaN if all animals are in the same group. If no input is provided([]), prompts appear.
groupnos=tkgroupnumbers;
grouptype=[];
% thresholding for all groups
numperline=tknumberperline(groupnos);

% Variables which define what days of data to use. i.e. Since the screen is
% five days long and each trace will start at 10AM the day after load.
first=1; %delete these if you would rather answer a prompt each time
last=3;
actthresh=5; %threshold number of activity counts observed during the last 24hr of recording to ID dead animals.
sam=1; % input the sampling rate (time of each sample bin in minutes)
sr = 60/sam*24;

%Defining the x-axis for traces (in days)
be=1;
End=last-first+1;
Days=linspace(be,End,End);

% Sleep Variables
LDday=2; %specify which day of LD to analyze for sleep measures (from start of trace, not experiment)
sleepdef=5; %nos of minutes with no activity to be counted as sleep
sleepbin=30; %size of sleep binning (in minutes)
sleepsr=60/sleepbin*24;

Allprompt = 'Apply activity thresholding to remove dead animals (Y)? [Y]'; %Analysis will automatically remove dead animals.
ALL=input(Allprompt, 's');
if isempty(ALL)
    ALL = 'Y';
end

%Thresholding Variables
inactive=4; %set this to determine the length(in minutes) of inactivity preceeding arousal for inclusion in analysis
risen=10; %set this to manipulate the length of time (in minutes) to check for arousal after shaking.

%Arousals
shakeday=3; %enter the day since the start of the trace on which arousals occured.
shaketime=[3.3167,5.3167,7.3167]; %can enter the time (in hours post ZT0 on day of arousals) when shaking occured to rouse the flies. This can be provided as a single number or as a vector with all hours provided (in the case of multiple trials in the same night or the next day).
shakeintensity=[5,5,5]; %matrix to enter intensity/timing information for each mechanical arousal.
shakegroup=[1,1,1]; %Matrix to distinguish different conditions for averageing
shakelabel={'Moderate'}; %{'Mild','Moderate','Strong','Mild','Moderate','Strong'};

save('Variables.mat', '-mat');
%% Load files and calculate sleep logical matrix
tkfileload;
load('file_variables.mat', '-mat');

%  preallocating for speed
dlen=size(datatrim,1);
slen=dlen/sleepbin;
% Generates sliding window to define lack of activity as sleep
sleepsum=zeros(size(datatrim,1)-sleepdef,animalnos);
sleepsumend=ones(sleepdef,animalnos);
for i=1:animalnos
   for j=1:size(datatrim,1)-sleepdef
    sleepsum(j,i)=sum(datatrim(j:(j-1)+sleepdef,i));
   end
end
sleepsum=[sleepsum;sleepsumend]; %just padding the last five minutes with no sleep and very low activity

%locate all the sleep epochs and generates sleepdata logical matrix
sleepind=find(~sleepsum); %locates all the sleep epochs
sleepdata=zeros(size(datatrim));
for i=1:sleepdef
sleepdata(sleepind(5:end)+1-i)=1;
end
active=datatrim;
if strcmp(ALL,'Y') == 1
sleepdata(:,deadind)=NaN; %Remove all dead animals from sleep analysis
active(:,deadind)=NaN; %Remove all dead animals from activity analysis
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Arousal Thresholding Analysis
shakedayind=(shakeday-1)*sr;
shaketimeind=shaketime*60;

%%%calculating based on locomotor activity
%Generating matrix with necessary sleep data for all animals
for i=1:numel(shaketime)
    activity(:,:,i)=active(shakedayind+shaketimeind(i)-inactive:shakedayind+shaketimeind(i)+risen,1:end);
end

%Creates a logical matrix for each timepoint and each animal for arousals
arousal=zeros(numel(shaketime),animalnos);
for i=1:numel(shaketime)
    for j=1:animalnos
        if sum(activity(1:inactive,j,i))==0 && sum(activity(inactive+1:end,j,i))>=1
            arousal(i,j)=1;
        end
        if sum(activity(1:inactive,j,i))>=1
            arousal(i,j)=NaN;
        end
    end
end

%Calculating the number of flies meeting arousability criteria for each intensity and genotype
for i=group
    for j=1:numel(shaketime)
        asleep(j,i)=(numel(groupind(i):groupind(i+1)-1))-sum(isnan(arousal(j,groupind(i):groupind(i+1)-1)));
    end
end

%Calculating percentages of aroused flies for each trial
for i=group
    for j=1:numel(shaketime)
        arousal_percent(j,i)=nansum(arousal(j,groupind(i):groupind(i+1)-1))/asleep(j,i)*100;
    end
end
%Generating average percentage of aroused flies for each intensity and
%genotype
for i=group
    for j=unique(shakegroup)
        arousal_percent_avg(j,i)=mean(arousal_percent(find(shakegroup==(j)),i));
        arousal_percent_stdev(j,i)=std(arousal_percent(find(shakegroup==(j)),i))/sqrt(numel(find(shakegroup==(j))));
    end
end

%Creates a logical matrix for each timepoint and each animal that was awake
%prior to shaking
awake=zeros(numel(shaketime),animalnos);
for i=1:numel(shaketime)
    for j=1:animalnos
        if sum(activity(1:inactive-1,j,i))>=1
            awake(i,j)=1;
        end
    end
end

%Calculating percentage of flies already awake prior to shaking (for
%posterity and testing, not visualized)
for i=group
    for j=1:numel(shaketime)
        awake_percent(j,i)=nansum(awake(j,groupind(i):groupind(i+1)-1))/(numel(groupind(i):groupind(i+1)-1)-sum(isnan(awake(j,groupind(i):groupind(i+1)-1))))*100;
    end
end

%Generating Average Percentage of awake flies for each intensity
for i=group
    for j=unique(shakegroup)
        awake_percent_avg(j,i)=mean(awake_percent(find(shakegroup==(j)),i));
    end
end

%% Plotting Arousal Threshold Percentages According to Genotype
if numel(unique(shakegroup))==1
    figure
    c=categorical(groupnames);    
    hBar = bar(c,arousal_percent_avg);
        hold on
        ngroups = size(arousal_percent_avg, 1);
        nbars = size(arousal_percent_avg, 2);
        % Calculating the width for each bar group
        groupwidth = min(0.8, nbars/(nbars + 1.5));
        err=get(hBar, 'Xdata');
        errorbar(err,arousal_percent_avg, arousal_percent_stdev, '.');
        hold off
        xtickangle(45)
        ylabel('Percent Aroused')
        title('Flies Aroused By Mechanical Stimulus')
    saveas(gcf,strcat(foldername,' Arousal Threshold - Aroused Flies Bargraph','.pdf'),'pdf')

    figure
        c=categorical(groupnames); 
        bar(c,awake_percent_avg)
        xtickangle(45)
        ylabel('Percent Awake')
        title('Flies Awake Prior To Stimulus')
    saveas(gcf,strcat(foldername,' Arousal Threshold - Awake Flies Bargraph','.pdf'),'pdf')    
    
elseif numel(unique(shakegroup))>=2
    figure
        hBar = bar(arousal_percent_avg);
        hold on
        ngroups = size(arousal_percent_avg, 1);
        nbars = size(arousal_percent_avg, 2);
        % Calculating the width for each bar group
        groupwidth = min(0.8, nbars/(nbars + 1.5));
        err = cell2mat(get(hBar, 'Xdata')).'+[hBar.XOffset];
    %         groupwidth = min(0.8, nbars/(nbars + 1.5));
    %         for i = 1:nbars
    %             err = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
    %             errorbar(err,arousal_percent_avg(:,i), arousal_percent_stdev(:,i), '.');
    %         end
        errorbar(err,arousal_percent_avg, arousal_percent_stdev, '.');
        hold off
        legend(groupnames,'Location','northeastoutside')
        %xticklabels(shakelabel)
        xtickangle(45)
        ylabel('Percent Aroused')
        title('Flies Aroused By Mechanical Stimulus')
    saveas(gcf,strcat(foldername,' Arousal Threshold - Aroused Flies Bargraph','.pdf'),'pdf')

    figure
        bar(awake_percent_avg)
        legend(groupnames,'Location','northeastoutside')
        %xticklabels(shakelabel)
        xtickangle(45)
        ylabel('Percent Awake')
        title('Flies Awake Prior To Stimulus')
    saveas(gcf,strcat(foldername,' Arousal Threshold - Awake Flies Bargraph','.pdf'),'pdf')
end

%% Saving data to CSV files
linenos={'Line Nos'};
genotype={'Genotype'};
zt={'Zeitgeber Time'};
intense={'Intensity (g)'};
subject={'n='};
pa={'Percent Aroused'};


%Group Sizes
gp_sz{5,1}=sprintf('%s',string(linenos));
gp_sz{5,2}=sprintf('%s',string(genotype));
gp_sz{1,3}=sprintf('%s',string(zt));
gp_sz{3,3}=sprintf('%s',string(intense));
gp_sz{5,3}=sprintf('%s',string(subject));

for j=1:numel(group)
    for k=1:numel(shaketime)
    gp_sz{j+5,1}=sprintf('%s',string(group(j)));
    gp_sz{j+5,2}=sprintf('%s',string(groupnames(j)));
    gp_sz{2,k+2}=sprintf('%s',string(shaketime(k)));
    gp_sz{4,k+2}=sprintf('%s',string(shakeintensity(k)));
    gp_sz{j+5,k+2}=sprintf('%s',string(asleep(k,j)'));
    end
end
cell2csv(strcat(filename,' Arousal_Thresholding_Group_Sizes.csv'),gp_sz)

%Percent Aroused
p_a{5,1}=sprintf('%s',string(linenos));
p_a{5,2}=sprintf('%s',string(genotype));
p_a{1,3}=sprintf('%s',string(zt));
p_a{3,3}=sprintf('%s',string(intense));
p_a{5,3}=sprintf('%s',string(pa));

for j=1:numel(group)
    for k=1:numel(shaketime)
    p_a{j+5,1}=sprintf('%s',string(group(j)));
    p_a{j+5,2}=sprintf('%s',string(groupnames(j)));
    p_a{2,k+2}=sprintf('%s',string(shaketime(k)));
    p_a{4,k+2}=sprintf('%s',string(shakeintensity(k)));
    p_a{j+5,k+2}=sprintf('%s',string(arousal_percent(k,j)'));
    end
end
cell2csv(strcat(filename,' Arousal_Thresholding_Percent_Aroused.csv'),p_a)

%Average Percent Aroused by Intensity
p_avg{5,1}=sprintf('%s',string(linenos));
p_avg{5,2}=sprintf('%s',string(genotype));
p_avg{1,3}=sprintf('%s',string(intense));
p_avg{3,3}=sprintf('%s',string(pa));

for j=1:numel(group)
    for k=unique(shakegroup)
    p_avg{j+3,1}=sprintf('%s',string(group(j)));
    p_avg{j+3,2}=sprintf('%s',string(groupnames(j)));
    p_avg{2,k+2}=sprintf('%s',string(shakeintensity(k*(numel(shakeintensity)/numel(unique(shakegroup))))));
    p_avg{j+3,k+2}=sprintf('%s',string(arousal_percent_avg(k,j)'));
    end
end
cell2csv(strcat(filename,' Arousal_Thresholding_Avg_Percent_Aroused.csv'),p_avg)

%Std Dev Percent Aroused by Intensity
p_sd{5,1}=sprintf('%s',string(linenos));
p_sd{5,2}=sprintf('%s',string(genotype));
p_sd{1,3}=sprintf('%s',string(intense));
p_sd{3,3}=sprintf('%s',string(pa));

for j=1:numel(group)
    for k=unique(shakegroup)
    p_sd{j+3,1}=sprintf('%s',string(group(j)));
    p_sd{j+3,2}=sprintf('%s',string(groupnames(j)));
    p_sd{2,k+2}=sprintf('%s',string(shakeintensity(k*(numel(shakeintensity)/numel(unique(shakegroup))))));
    p_sd{j+3,k+2}=sprintf('%s',string(arousal_percent_stdev(k,j)'));
    end
end
cell2csv(strcat(filename,' Arousal_Thresholding_StDev_Percent_Aroused.csv'),p_avg)

save('Arousal_Variables.mat', '-mat');
toc
clear all;
