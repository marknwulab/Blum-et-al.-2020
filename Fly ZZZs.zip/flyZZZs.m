%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: 
% Analysis of Drosophila sleep parameters with sleep deprivation 
% Input is a single folder containing only DAMfile scan produced activity
% files in 1-min bins, starting at ZT0 (lights on) of the day after
% loading (but these parameters can be changed below)
% 
% Tested and Verified with Matlab 2018b
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% To Do for Code
% to be done
%   day/night and daily total activity time in minutes across days and
%   genotype FS
%     (if we care about arousal I guess, might add this later)
%   day/night activity/sleep bout count and mean bout duration across days
%       and genotype (consider plotting this as a count nos vs bout length
%       using both colour and shape to distinguish individuals)
%   day/night brief awakenings (how is this defined?) 
%       Brief awakenings refers to 5-min periods with four or fewer activity counts that were
%       preceded and succeeded by a minimum of 5?minutes of inactivity (Koh Sehgal PNAS 2006)
%       histograms for sleep/activity bout length distributions
%   incorporate paddingzeros code so that incomplete files are automatically fixed so they can be used to look at
%   data prior to termination of the experiment
%   Need to write a new analysis script to analyze baseline sleep in
%       experiments that do not have any manipulations (i.e. no DD and no SD).
%       This can incorporate code from flycirc to look at sleep
%       fragmentation making this a more full package

%  to be considered:
%   -Sleep consolidation curve = determine total sleep time as a function of the sleep definition (in minutes)
%   -Zscore sleep data (TST, Rebound, etc.) to ID outliers for screen
%   (might consider doing ICA for cluster analysis across all variables, maybe too hibrow?)
%%
close all;
clearvars;
addpath('C:\Users\ian_d\Documents\matlab\Circadian Scripts and Functions\Drosophila\Fly ZZZs')
tic
set(0,'DefaultFigureVisible','off')
%% variables
%Nos of animals used for each line of the screen, either as a single number
%for evenly sized groups or vector with individual groupsizes 
%eg. groupnos=[x,y,z,aa,etc.]. Use NaN if all animals are in the same group. If no input is provided([]), prompts appear.
% groupnos=[];
groupnos=tkgroupnumbers;    %use [], NaN,msi or tkgroupnumbers;
numperline=tknumberperline(groupnos);
C='C';E='E';grouptype={C}; %similarly this is a cell where E=experimental and
% C=control groups eg. ={C,C,E,E}, if all entries are the same enter one i.e. {E} 
%or leave blank([]) to ignore deprivation thresholding for all groups

% Variables which define what days of data to use. Day 1 represents the
% first 24hrs of the recording.
first=2; %delete these if you would rather answer a prompt each time
last=4;
actthresh=5; %threshold number of activity counts observed during the last 24hr of recording to ID dead animals.

sam=1; % input the sampling rate (time of each sample bin in minutes)
sr = 60/sam*24;

%Defining the x-axis for traces (in days)
be=1;
End=last-first+1;
Days=linspace(be,End,End);

%Prompts for type of analysis
[GRAPH,ALL,DD,DEP,PULSE,PULSE2]=sleepprompts;

% Sleep Variables
LDday=2; %specify which day of LD to analyze for sleep measures (from start of trace, not experiment)
sleepdef=5; %nos of minutes with no activity to be counted as sleep
sleepbin=30; %size of sleep binning (in minutes)
sleepsr=60/sleepbin*24;

%variables for sleep analysis in LD and DD
if strcmpi(DD,'Y') == 1
daysLD=2; %nos of days of L:D prior to D:D (assumes data begins at ZT0)
DDday=2; %specify which day of DD to analyze for sleep measures
DDday=daysLD+DDday; %converts DDay into time since beginning
else
daysLD=End;
end

%Variables for circadian analysis
perlow=18; %lower limit of period to be tested
perhi=30; %upper limit of period to be tested
perres=0.1; %resolution of period range to be tested in hours
perrange=perlow/24:perres/24:perhi/24; %range of periods to be tested for cosinor fit

%variables for sleep analysis with deprivation
if strcmpi(DEP,'Y') == 1
Depstart=2.5; %start of sleep deprivation period in days from start of trace (N.B. first day of recording is day 1)
Depend=ceil(Depstart); %end of sleep deprivation period in days   
depday=floor(Depstart);
baseday=depday-1;
recoday=depday+1;%change this to recoday=depday+1 if you want to look at recovery
depthresh=85; %defines the deprivation threshold for retaining flies for analysis (in % deprived)
recobin=6; %defines the timespan (in hours from ZT0) used for recovery analysis.
groupplotlim=10; %Alters the limits of how many groups get plotted in "Locomotor and Sleep Trace Comparisons AND Percent Sleep Recovered Trace". If # groups is greater no plots are generated.
end
if strcmpi(PULSE,'Y') == 1
pulse=1; %length of pulse (h)
Depstart=3; %start of sleep deprivation pulse in days (N.B. first day of recording is day 1)
Depend=Depstart + pulse/24; %end of activation period in days   
depday=floor(Depstart);
baseday=depday-1;
recoday=depday; %change this to recoday=depday+1 if you want to look at recovery
depthresh=0; %defines the deprivation threshold for retaining flies for analysis (%)
recobinpulse=6; %defines the timespan (in hours from end of pulse) used for recovery analysis.
end
if strcmpi(PULSE2,'Y') == 1
nightpulsestart=6.5;
nightpulseend=7;
nightpulseday=floor(nightpulsestart);
end

%Variables for calculating Sleep bout length and nos during day and night
%(but can adjust ranges to restrict it to midday and midnight as in
%Tabuchi et al. Cell 2018 or to calculate fragmentation during the first
%six hours of rebound). 
midds=(baseday-1)*24; %0 %start of midday
midde=(baseday-1)*24+12; %12 %end of midday
midns=(baseday-1)*24+12; %12 %start of midnight
midne=(depday-1)*24; %24 %end of midnight

if strcmpi(DEP,'Y') == 1
midas=(depday*24)-12; %start of deprivation/Overnight activation
midae=(depday*24); %end of deprivation/Overnight activation
midrs=(depday*24); %start of rebound period
midre=(depday*24)+recobin; %end of rebound period
    if strcmpi(PULSE,'Y') == 1
    midas=(baseday*24); %start of activation
    midae=(baseday*24)+pulse; %end of activation
    midrs=(baseday*24)+pulse; %0 %start of rebound period
    midre=(baseday*24)+pulse+recobinpulse; %end of rebound period
    end
end

save('Variables.mat', '-mat');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Generate only sleep traces for quick visualization without quantitation
if strcmpi(GRAPH,'V') == 1
    tkfileload;
    tksleeptrace;
end
%% Sleep analysis
if strcmpi(GRAPH,'A') == 1  
    if strcmpi(DD,'Y') == 1
        tkcircfileload;
        tkcircsleepLDDD
        tkcircwrtslpdata; % Creating excel file with sleep data
    end

    if strcmpi(DEP,'Y') == 1
        [groupnumbers]=tkfileload;
        tksleepdep_parfor;
        if groupnumbers>=2
        tkanova;
        end
        tkwritesleepdata; % Creating excel file with sleep data including line analyses
    end
end
set(0,'DefaultFigureVisible','on');
toc
clearvars;
close all;