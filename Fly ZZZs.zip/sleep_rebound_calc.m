      
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
load('SleepDep_variables.mat', '-mat');
recoday=4;
baseday=3;
recobin=12;
clear sleepreboundbin
    for i=1:animalnos;
sleepreboundbin(i)=sum(sleepdata((recoday-1)*sr:((recoday-1)+(recobin/24))*sr-1,i))-mean([sum(sleepdata((baseday-1)*sr:((baseday-1)+(recobin/24))*sr-1,i)) sum(sleepdata((depday-1)*sr:((depday-1)+(recobin/24))*sr-1,i))]);
    end
figure
boxplot(sleepreboundbin,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Rebound Sleep'))
    ylim([min(sleepreboundbin)*1.1 max(sleepreboundbin)*1.1])
    saveas(gcf,strcat(foldername,' 12hr pulse Rebound Sleep by line','.pdf'),'pdf')
