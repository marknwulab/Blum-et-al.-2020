function [GRAPH,ALL,DD,DEP,PULSE,PULSE2]=sleepprompts(varargin)

Graphprompt = 'Would you like to (A)nalyze or just (V)isualize? (A/V) [A]: '; %Analysis will automatically remove dead animals, Visualize will prompt.
GRAPH=input(Graphprompt, 's');
if isempty(GRAPH)
    GRAPH = 'A';
end

Allprompt = 'Apply activity thresholding to remove dead animals (Y/N)? [Y]'; %Analysis will automatically remove dead animals, Visualize will prompt.
ALL=input(Allprompt, 's');
if isempty(ALL)
    ALL = 'Y';
end

DDprompt = 'Is there any data in constant darkness? (Y/N) [N]: ';
DD=input(DDprompt, 's');
if isempty(DD)
    DD = 'N';
end

Depprompt = 'Is there any sleep deprivation ? (Y/N) [Y]: ';
DEP=input(Depprompt, 's');
if isempty(DEP)
    DEP = 'Y';
end

if strcmpi(DEP,'Y') == 1;
pulseprompt = 'Is sleep deprivation a daytime pulse (starting at ZT0)? (Y/N) [N]: ';
PULSE=input(pulseprompt, 's');
    if isempty(PULSE)
    PULSE = 'N';
    end
else
    PULSE = 'Y';
end

if strcmpi(DEP,'Y') == 1
overnightprompt = 'Is there a second heat pulse at the end of the experiment? (Y/N) [N]: ';
PULSE2=input(overnightprompt, 's');
    if isempty(PULSE2)
    PULSE2 = 'N';
    end
else
    PULSE2 = 'Y';
end