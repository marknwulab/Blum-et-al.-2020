%Take outputs from tksleepdep and perform z-scoring, outlier detection,
%multivariate analysis, PCA, and clustering analysis for screening purposes

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=tkanova(varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
load('SleepDep_variables.mat', '-mat');

% Sets the cutoff for outliers (in Std Deviations)
alpha=0.05;

%% Run Anovas
%Generate matrices to handle key output variables

if strcmpi(PULSE2,'Y') == 1
    varnames={'Bline TST','Bline Day TST','Bline Night TST','Post-Pulse TST',...
    'Post-Pulse Day TST','Post-Pulse Night TST','Recovery TST','Recovery Day TST',...
    'Recovery Night TST','Sleep Recovery','Sleep Rebound','Percent Sleep Recovered','Normalized Percent Sleep Recovered','Overnight Pulse','Sleep Latency','Rebound Latency'};
    varcell=[sleeppredep;daysleeppredep;nightsleeppredep;sleepdep;...
    daysleepdep;nightsleepdep;sleepreco;daysleepreco;...
    nightsleepreco;sleeprecobin;sleepreboundbin;percsleeprecovbin;normpercsleeprecovbin;nightsleeppulse;latencyN(baseday,:);reblat];
elseif strcmpi(DEP,'Y') == 1
    varnames={'Bline TST','Bline Day TST','Bline Night TST','Treatment TST',...
    'Treatment Day TST','Treatment Night TST','Recovery TST','Recovery Day TST',...
    'Recovery Night TST','Sleep Recovery','Sleep Rebound','Percent Sleep Recovered','Normalized Percent Sleep Recovered','Sleep Latency',...
    'Rebound Latency','Sleep Bout Nos','Sleep Bout Avg Length','Night Sleep Bout Nos','Night Sleep Bout Avg Length','Day Sleep Bout Nos',...
    'Day Sleep Bout Avg Length','Activation Sleep Bout Nos','Activation Sleep Bout Avg Length','Rebound Sleep Bout Nos','Rebound Sleep Bout Avg Length','Waking Activity During Treatment','Waking Activity During Recovery'};
    varcell=[sleeppredep;daysleeppredep;nightsleeppredep;sleepdep;...
    daysleepdep;nightsleepdep;sleepreco;daysleepreco;...
    nightsleepreco;sleeprecobin;sleepreboundbin;percsleeprecovbin;normpercsleeprecovbin;latencyN(baseday,:);reblat;...
    sleepboutnos(baseday,:);sleepboutavg(baseday,:);sleepboutnosnight;sleepboutavgnight;sleepboutnosday;...
    sleepboutavgday;sleepboutnosactivation;sleepboutavgactivation;sleepboutnosrebound;sleepboutavgrebound;activenightwakemeandep;activedaywakemeanreco];
end
    

% find avg of each variable by line
for i=1:length(varnames)
    for j=1:groupnumbers
    groupvar(i,j)= nanmean(varcell(i,find(grouping == j)));
    end
end

% rearrange each variable into table suitable for anova
for i=1:length(varnames)        
anovar{i}=NaN(max(groupnos),groupnumbers);
end

for i=1:length(varnames)
    for j=1:groupnumbers
        if numel(groupnos)==1
        anovar{i}(1:groupnos,j)=varcell(i,find(grouping == j))';
        else
        anovar{i}(1:groupnos(j),j)=varcell(i,find(grouping == j))';
        end
    end
end
clear i j k
%calculate statistics including p-value (p), ANOVA table (tbl), and a structure used for multiple comparisons (stats) 
for i=1:length(varnames)
    [p(i),tbl{i},stats{i}]=anova1(anovar{i}, groupnames);
    title(gca,varnames{i})
    xtickangle(45)
    saveas(gcf,strcat(foldername,' Sleep Parameter ANOVA boxplot_',varnames{i},'.pdf'),'pdf')    
end

    for i=1:length(varnames)
%         if p(i)<=alpha
            C=tbl{1,i};
            TC=table(C);
            writetable(TC,strcat(foldername,' Sleep Parameter ANOVA Tables_',varnames{i},'.xlsx'));
            clear TC
%         end
    end

    if groupnumbers>2
        for i=1:length(varnames)
%             if p(i)<=alpha
            [bonferroni{i},~,h1]=multcompare(stats{i},'Alpha',alpha,'Ctype','dunn-sidak','Display','off');
%         end
    end
    
        for i=1:length(varnames)
%             if p(i)<=alpha
                B=bonferroni{i};
                TB=table(B);
                writetable(TB,strcat(foldername,' Sleep Parameter MultCmp Tables_',varnames{i},'.xlsx'));
                clear TB
%             end
    end
end
close all;
save('SleepDep_ANOVA.mat', '-mat');

%% need to add a way for the significant lines (group number and phenotype)
% to be added to the existing excel sheet or can be exported into it's own
% sheet.
