%Take outputs from tksleepdep and perform z-scoring, outlier detection,
%multivariate analysis, PCA, and clustering analysis for screening purposes

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=tkcircgroupplot(subject)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
load('Sleep_variables.mat', '-mat');

subplot(2,1,1)
    Ylim=max(activelineavg(:,subject));
    fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
    hold on
    fill(darkfillx,darkfilly*Ylim,'k','FaceAlpha',0.1)
    plot(time,activelineavg(:,subject),'k','LineWidth',2);
    ylabel('Activity (cnts)')
    if Ylim > 1
        ylim([0 Ylim])
    else
        ylim([0 1])
    end
    title(strcat(groupnames{subject},' Activity and Sleep Profiles'));
    hold off
    subplot(2,1,2)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    fill(darkfillx,darkfilly*100,'k','FaceAlpha',0.1)
    plot(sleeptime,sleepproblineavg(:,subject),'k','LineWidth',2);
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
    print(gcf,strcat('Line Avg ',groupnames{subject},' Locomotor and Sleep Trace','.pdf'),'-dpdf');