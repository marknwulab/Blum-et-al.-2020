%Run and plot sleep data for locomotor traces when there is LD followed by DD
%lighting conditions in the recording

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=tkcircsleepLDDD(varargin)

load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
%  preallocating for speed
dlen=size(datatrim,1);
slen=dlen/sleepbin;

% Generates sliding window to define lack of activity as sleep
sleepsum=zeros(size(datatrim,1)-sleepdef,animalnos);
sleepsumend=ones(sleepdef,animalnos);
for i=1:animalnos
   for j=1:size(datatrim,1)-sleepdef
    sleepsum(j,i)=sum(datatrim(j:(j-1)+sleepdef,i));
   end
end
sleepsum=[sleepsum;sleepsumend]; %just padding the last five minutes with no sleep and very low activity

%locate all the sleep epochs and generates sleepdata logical matrix
sleepind=find(~sleepsum); %locates all the sleep epochs
sleepdata=zeros(size(datatrim));
for i=1:sleepdef
sleepdata(sleepind(5:end)+1-i)=1;
end
active=datatrim;
if strcmp(ALL,'Y') == 1
sleepdata(:,deadind)=NaN; %Remove all dead animals from sleep analysis
active(:,deadind)=NaN; %Remove all dead animals from activity analysis
end

% Calculating the final group sizes after accounting for dead animals
groupsind=isnan(sleepdata(1,:));
groups=ones(1,animalnos).*~groupsind;
temp=zeros(1,animalnos);temp(deadind)=1;deadgroups=temp;
groupsize=zeros(1,groupnumbers);deadsize=zeros(1,groupnumbers);
    for i=group
    groupsize(i)=sum(groups(groupind(i):groupind(i+1)-1));
    deadsize(i)=sum(deadgroups(groupind(i):groupind(i+1)-1));
    end

%finding sleep probability per bin
sleeptime=((1:size(sleepdata,1)/sleepbin)/sleepsr)+1; %generates a timeseries for sleepbinning
sleepprob=zeros(slen,animalnos);
sb=sleepbin;
for i=1:animalnos
   sd=sleepdata(:,i);
   for j=1:slen
   sbtrim=(sb*j)-sb+1:sb*j;
   sleepprob(j,i)=sum(sd(sbtrim))/sb*100;
   end
end

% %Total Sleep time per day
% for i=1:animalnos
%     sleepLD(i)=sum(sleepdata((LDday-1)*sr+1:LDday*sr,i));
%     sleepprobLD=sleepLD./sr*100;
%     sleepDD(i)=sum(sleepdata((DDday-1)*sr+1:DDday*sr,i));
%     sleepprobDD=sleepDD./sr*100;
% end

%Total Sleep Time (TST) for designated days in LD and DD
% technically need to rewrite this so that the DD estimates take circadian
% period into account, otherwise this will be thrown off by extreme period
% outliers. Period outliers are being excluded manually from our screen so I wont worry
% about it for now but it may become necessary in the future.
if strcmpi(DD,'Y') == 1
    LDtrim=(LDday-1)*sr+1:LDday*sr;
    LDtrimday=(LDday-1)*sr+1:(LDday-0.5)*sr;
    LDtrimnight=(LDday-0.5)*sr+1:LDday*sr;
    DDtrim=(DDday-1)*sr+1:DDday*sr;
    DDtrimday=(DDday-1)*sr+1:(DDday-0.5)*sr;
    DDtrimnight=(DDday-0.5)*sr+1:DDday*sr;
    parfor i=1:animalnos
    sleepLD(i)=sum(sleepdata(LDtrim,i)); %consider moving sleepdata slices outside the forloop for greater performance e.g. LDtrim=sleepdata((LDday-1)*sr+1:LDday*sr,:) and sleepLD(i)=sum(LDtrim(i))
    sleepLDday(i)=sum(sleepdata(LDtrimday,i));
    sleepLDnight(i)=sum(sleepdata(LDtrimnight,i));
    sleepDD(i)=sum(sleepdata(DDtrim,i));
    sleepDDday(i)=sum(sleepdata(DDtrimday,i));
    sleepDDnight(i)=sum(sleepdata(DDtrimnight,i));
    end
sleepprobLD=sleepLD./sr*100;
sleepprobLDday=sleepLDday./sr*100;
sleepprobLDnight=sleepLDnight./sr*100;
sleepprobDD=sleepDD./sr*100;
sleepprobDDday=sleepDDday./sr*100;
sleepprobDDnight=sleepDDnight./sr*100;
end

%Calculate ratio between daytime sleep and nighttime sleep for LD and DD
DNratioLD=sleepLDday./sleepLDnight;
DNratioDD=sleepDDday./sleepDDnight;

%locate all sleep/wake transitions
krn=[1 -1];
transitions=zeros(dlen+1,animalnos);
wtsind=cell(1,animalnos);
stwind=cell(1,animalnos);
parfor k=1:animalnos
    transitions(:,k)=conv(krn,sleepdata(:,k));
    wtsind{1,k}=find(transitions(:,k)==1); %all wake to sleep transitions
    stwind{1,k}=find(transitions(:,k)==-1); %all sleep to wake transitions
end

%calculating nos and length of all wakefulness and sleep bouts by day
sleepbouts=cell(End,animalnos);
wakebouts=cell(End,animalnos);
sleepboutnos=NaN(End,animalnos);
sleepboutavg=NaN(End,animalnos);
wakeboutnos=NaN(End,animalnos);
wakeboutavg=NaN(End,animalnos);
for i=1:animalnos
    for j=1:End
        tempwind=find(wtsind{i}>=(j-1)*sr & wtsind{i}<=j*sr);
        tempsind=find(stwind{i}>=(j-1)*sr & stwind{i}<=j*sr);
        if numel(tempwind)>numel(tempsind)
        sleepbouts{j,i} = stwind{i}(tempsind)-wtsind{i}(tempwind(1:end-1)); % need to recode this to not ignore the bout at the transition
        wakebouts{j,i} = wtsind{i}(tempwind(2:end))-stwind{i}(tempsind);% need to recode this to not ignore the bout at the transition
        elseif numel(tempwind)<numel(tempsind)
        sleepbouts{j,i} = stwind{i}(tempsind(2:end))-wtsind{i}(tempwind);% need to recode this to not ignore the bout at the transition
        wakebouts{j,i} = wtsind{i}(tempwind)-stwind{i}(tempsind(1:end-1));% need to recode this to not ignore the bout at the transition
        else
            if isempty(tempwind)==0
                if tempsind(end)>=tempwind(end)
                sleepbouts{j,i} = stwind{i}(tempsind)-wtsind{i}(tempwind);
                wakebouts{j,i} = wtsind{i}(tempwind(2:end))-stwind{i}(tempsind(1:end-1));
                else
                sleepbouts{j,i} = stwind{i}(tempsind(2:end))-wtsind{i}(tempwind(1:end-1));
                wakebouts{j,i} = wtsind{i}(tempwind)-stwind{i}(tempsind);
                end
            else
            sleepbouts{j,i} = NaN;
            wakebouts{j,i} = NaN;
            end
        end
%use this snippet of code to test for errors in bout analysis (so far so good)
            if isempty(find(wakebouts{j,i}<0,1))==0 || isempty(find(sleepbouts{j,i}<0,1))==0;
            error('there is an error in the bout analysis please check code')
            end
        sleepboutnos(j,i)=numel(sleepbouts{j,i});
        sleepboutavg(j,i)=nanmean(sleepbouts{j,i}).*sam;
        wakeboutnos(j,i)=numel(wakebouts{j,i});
        wakeboutavg(j,i)=nanmean(wakebouts{j,i}).*sam;
    end
end

if strcmp(ALL,'Y') == 1
    for i=1:End
    sleepboutnos(i,deadind)=NaN;
    sleepboutavg(i,deadind)=NaN;
    wakeboutnos(i,deadind)=NaN;
    wakeboutavg(i,deadind)=NaN;
    end
end
    
% Calculating Sleep bout length and nos during for day/night comparisons
% (N.B. that this can be used to look at fragmentation mid phase as in
% Tabuchi et al. Cell 2018 by adjusting the midds,midns,midde, and midne
% parameters to reflect the more limited time spans

%This is for baseline sleep fragmentation 
for i=1:animalnos
        tempwindday=find(wtsind{i}>=((baseday-1)*sr)+(midds*60/sam) & wtsind{i}<=((baseday-1)*sr)+(midde*60/sam));
        tempwindnight=find(wtsind{i}>=((baseday-1)*sr)+(midns*60/sam) & wtsind{i}<=((baseday-1)*sr)+(midne*60/sam));
        tempsindday=find(stwind{i}>=((baseday-1)*sr)+(midds*60/sam) & stwind{i}<=((baseday-1)*sr)+(midde*60/sam));
        tempsindnight=find(stwind{i}>=((baseday-1)*sr)+(midns*60/sam) & stwind{i}<=((baseday-1)*sr)+(midne*60/sam));
        tempwday=wtsind{i}(tempwindday);
        tempwnight=wtsind{i}(tempwindnight);
        tempsday=stwind{i}(tempsindday);
        tempsnight=stwind{i}(tempsindnight);
        %day
        if isempty(tempsindday)==1 && isempty(tempwindday)==1
            sleepboutsday{i}=sum(sleepdata((midds*60/sam)+1:(midde*60/sam)-1,i));
        elseif numel(tempsindday)==1 && numel(tempwindday)==1
            if tempsday<tempwday
            sleepboutsday{i}= [tempsday-((midds*60/sam)+1);((midde*60/sam)-1)-tempwday]; %take stw-start & end-wts
            else
            sleepboutsday{i}=tempsday-tempwday; %stw-wts
            end
        elseif isempty(tempwindday)==1 && isempty(tempsindday)==0
            sleepboutsday{i}=tempsday-(midde*60/sam); %stw-start
        elseif isempty(tempwindday)==0 && isempty(tempsindday)==1        
            sleepboutsday{i}=(midde*60/sam)-tempwday; %end-wts
        elseif isempty(tempwindday)==0 && isempty(tempsindday)==0
            if numel(tempwindday)>numel(tempsindday)
            sleepboutsday{i} = [tempsday;(midde*60/sam)]-tempwday;
            elseif numel(tempwindday)<numel(tempsindday)
            sleepboutsday{i} = tempsday-[(midds*60/sam);tempwday];
            elseif numel(tempwindday)==numel(tempsindday)
                if tempwday(end)<tempsday(end)
                sleepboutsday{i} = tempsday-tempwday;
                else
                sleepboutsday{i} = [tempsday;(midde*60/sam)]-[(midds*60/sam);tempwday];    
                end
            end
        end
        %night
        if isempty(tempsindnight)==1 && isempty(tempwindnight)==1
            sleepboutsnight{i}=sum(sleepdata((midns*60/sam)+1:(midne*60/sam-1),i));
        elseif numel(tempwindnight)==1 && numel(tempsindnight)==1
            if tempsnight<tempwnight
            sleepboutsnight{i}= [tempsnight-(midns*60/sam);(midne*60/sam-1)-tempwnight]; %take stw-start & end-wts
            else
            sleepboutsnight{i}=tempsnight-tempwnight; %stw-wts
            end
        elseif isempty(tempwindnight)==1 && isempty(tempsindnight)==0
            sleepboutsnight{i}=tempsnight-((midns*60/sam)+1); %stw-start
        elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==1        
            sleepboutsnight{i}=((midne*60/sam)-1)-tempwnight; %end-wts
        elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==0
            if numel(tempwindnight)>numel(tempsindnight)
            sleepboutsnight{i} = [tempsnight;(midne*60/sam)-1]-tempwnight;
            elseif numel(tempwindnight)<numel(tempsindnight)
            sleepboutsnight{i} = tempsnight-[(midns*60/sam)+1;tempwnight];
            elseif numel(tempwindnight)==numel(tempsindnight)
                if tempwnight(end)<tempsnight(end)
                sleepboutsnight{i} = tempsnight-tempwnight;
                else
                sleepboutsnight{i} = [tempsnight;(midne*60/sam)-1]-[(midns*60/sam)+1;tempwnight];    
                end
            end
        end
%use this snippet of code to test for errors in bout analysis (so far so good)
if isempty(find(wakebouts{i}<0,1))==0 || isempty(find(sleepbouts{i}<0,1))==0
error('there is an error in the bout analysis please check code')
end

sleepboutnosday(i)=numel(sleepboutsday{i});
    if isempty(sleepboutnosday(i)) || isnan(sleepboutnosday(i))
    sleepboutnosday(i) = 0;
    elseif sum(sleepboutsday{i})==0
    sleepboutnosday(i) = 0;
    end
sleepboutavgday(i)=nanmean(sleepboutsday{i}).*sam;

sleepboutnosnight(i)=numel(sleepboutsnight{i});
    if isempty(sleepboutnosnight(i)) || isnan(sleepboutnosnight(i))
    sleepboutnosnight(i) = 0;
    elseif sum(sleepboutsnight{i})==0
    sleepboutnosnight(i) = 0;
    end
sleepboutavgnight(i)=nanmean(sleepboutsnight{i}).*sam;

sleepboutnosratio(i)=sleepboutnosday(i)/sleepboutnosnight(i); %bout nos
sleepboutavgratio(i)=sleepboutavgday(i)/sleepboutavgnight(i); %bout length
end
if strcmp(ALL,'Y') == 1
sleepboutnosday(deadind)=NaN;
sleepboutnosnight(deadind)=NaN;
sleepboutavgday(deadind)=NaN;
sleepboutavgnight(deadind)=NaN;
sleepboutnosratio(deadind)=NaN;
sleepboutavgratio(deadind)=NaN;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % rework this section according to notes for sleep and wake anticipation
% % and/or transition slopes for each group average

wakeLDonsettrace=sleepproblineavg((LDday-1)*sleepsr-(0.25*sleepsr):(LDday-1)*sleepsr+(0.25*sleepsr),:);
wakeDDonsettrace=sleepproblineavg((DDday-1)*sleepsr-(0.25*sleepsr):(DDday-1)*sleepsr+(0.25*sleepsr),:);
wakeLDonsettime=sleeptime((LDday-1)*sleepsr-(0.25*sleepsr):(LDday-1)*sleepsr+(0.25*sleepsr));
wakeDDonsettime=sleeptime((DDday-1)*sleepsr-(0.25*sleepsr):(DDday-1)*sleepsr+(0.25*sleepsr));

sleepLDonsettrace=sleepproblineavg((LDday-1)*sleepsr+(0.25*sleepsr):(LDday-1)*sleepsr+(0.75*sleepsr),:); %finding sleep trace surrounding onset in LD
sleepDDonsettrace=sleepproblineavg((DDday-1)*sleepsr+(0.25*sleepsr):(DDday-1)*sleepsr+(0.75*sleepsr),:); %finding sleep trace surrounding onset in DD
sleepLDonsettime=sleeptime((LDday-1)*sleepsr+(0.25*sleepsr):(LDday-1)*sleepsr+(0.75*sleepsr));
sleepDDonsettime=sleeptime((DDday-1)*sleepsr+(0.25*sleepsr):(DDday-1)*sleepsr+(0.75*sleepsr));
save('Sleep_variables.mat', '-mat');
%fitting sigmoids to each of these curves then extracting relevant
%parameters like x50 (taken as the onset time)
%param = [min, max, x50, slope], where the x50 is to be considered the
%onset time for each measurement % consider changing it from days to phase
%angle from ZT/CT0
warning off;
mkdir(strcat(pwd,'\Onsets'))
for i=group
    if sum(isnan(sleepproblineavg(:,i)))~=numel(sleeptime)
    [LDactparam{i},LDactstat{i}]=sigm_fit(wakeLDonsettime,wakeLDonsettrace(:,i),[],[],1);
    title(strcat(groupnames{i},' Activity Onset LD Sigmoid Fit','.pdf'));
    saveas(gcf,strcat(pwd,'\Onsets\',groupnames{i},' Activity Onset LD Sigmoid Fit','.pdf'),'pdf');
    [DDactparam{i},LDactstat{i}]=sigm_fit(wakeDDonsettime,wakeDDonsettrace(:,i),[],[],1);
    title(strcat(groupnames{i},' Activity Onset DD Sigmoid Fit','.pdf'));
    saveas(gcf,strcat(pwd,'\Onsets\',groupnames{i},' Activity Onset DD Sigmoid Fit','.pdf'),'pdf');
    [LDsleepparam{i},LDsleepstat{i}]=sigm_fit(sleepLDonsettime,sleepLDonsettrace(:,i),[],[],1);
    title(strcat(groupnames{i},' Sleep Onset LD Sigmoid Fit','.pdf'));
    saveas(gcf,strcat(pwd,'\Onsets\',groupnames{i},' Sleep Onset LD Sigmoid Fit','.pdf'),'pdf');
    [DDsleepparam{i},DDsleepstat{i}]=sigm_fit(sleepDDonsettime,sleepDDonsettrace(:,i),[],[],1);
    title(strcat(groupnames{i},' Sleep Onset DD Sigmoid Fit','.pdf'));
    saveas(gcf,strcat(pwd,'\Onsets\',groupnames{i},' Sleep Onset DD Sigmoid Fit','.pdf'),'pdf');
    end
end

for k=group
    if sum(isnan(sleepproblineavg(:,k)))~=numel(sleeptime)
    activityonsets(:,k)=[(LDactparam{k}(3)-floor(LDactparam{k}(3)))*360 (DDactparam{k}(3)-floor(DDactparam{k}(3)))*360];
    sleeponsets(:,k)=[(LDsleepparam{k}(3)-floor(LDsleepparam{k}(3)))*360 (DDsleepparam{k}(3)-floor(DDsleepparam{k}(3)))*360];
    else
    activityonsets(:,k)=[NaN NaN];
    sleeponsets(:,k)=[NaN NaN];
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cosinor analysis for DD component
clear i j Amp M phi RSS RSSind p_val
sleepDDtrace=sleepprob((daysLD)*sleepsr+1:end,:);
sleepDDtime=sleeptime((daysLD)*sleepsr+1:end);
perrange=perlow/24:perres/24:perhi/24;
plotprompt='N';
save('Sleep_variables.mat', '-mat');
addAttachedFiles(gcp,{'Variables.mat';'Sleep_variables.mat'})
%Calculating Cosinor fits for DD sleep data
parfor i=1:animalnos
    Mt=NaN(length(perrange),1);
    Ampt=NaN(length(perrange),1);
    phit=NaN(length(perrange),1);
    RSSt=NaN(length(perrange),1);
    p_valt=NaN(length(perrange),1);
    slt=sleepDDtrace(:,i);
    for j=1:length(perrange)
        if sum(isnan(slt))==length(slt)
        Mt(j,1)=NaN;Ampt(j,1)=NaN;phit(j,1)=NaN;RSSt(j,1)=NaN;p_valt(j,1)=NaN;
        else
        [Mt(j,1),Ampt(j,1),phit(j,1),RSSt(j,1),p_valt(j,1)] = cosinor_forloop(sleepDDtime',slt,perrange(j),0.05,plotprompt);
        end
    end
    RSSpar(:,i)=RSSt;
    Mpar(:,i)=Mt;
    Amppar(:,i)=Ampt;
    phipar(:,i)=phit;
    RSSpar(:,i)=RSSt;
    p_valpar(:,i)=p_valt;
end

%Selecting best fit parameters (minimizing RSS) for each animal
mkdir(strcat(pwd,'\Cosinor'))
parfor i=1:animalnos
    [RSS(i), RSSind(i)]=min(RSSpar(:,i));
    M(i)=Mpar(RSSind(i),i);
    Amp(i)=Amppar(RSSind(i),i);
    phi(i)=phipar(RSSind(i),i);
    p_val(i)=p_valpar(RSSind(i),i);
    per(i)=perrange(RSSind(i))*24; %calculates the cosinor period estimate in hours
    slt=sleepDDtrace(:,i);
    %Plot orginal data and cosine fit
    w=(24/per(i))*2*pi;
    wave = M(i) + Amp(i)*cos(w.*sleepDDtime+phi(i));
        if sum(isnan(slt))~=length(slt)
        plot(sleepDDtime,slt); hold on;
            xlabel('Time (hrs since start)');
            ylabel('Total Sleep Time per bin (min)')
            xlim([min(sleepDDtime) max(sleepDDtime)]);
            ylim([min(sleepDDtrace(:,i)) max(sleepDDtrace(:,i))]);
        plot(sleepDDtime,wave,'r');
            legend('Sleep', 'Cosinor');
            xlim([min(sleepDDtime) max(sleeptime)]);
            hold off
            saveas(gcf,strcat(pwd,'\Cosinor\','Cosinor ',textfilenames{i},'.pdf'),'pdf');
        end
end
close all;
%Making sure only statistically significant Cosinor periods and phases are included
perinsig=find(p_val>0.05);
p_valinsig=find(isnan(p_val)==1);
per(perinsig)=NaN;
per(p_valinsig)=NaN;
phi(perinsig)=NaN;
phi(p_valinsig)=NaN;


%still need a way to identify genotypes/groups that all all insignificant
%according to the Fzero amplitude test.

for i=group
    peravg(:,i) = mean(per(groupind(i):groupind(i+1)-1));
    Mavg(i) = nanmean(M(groupind(i):groupind(i+1)-1));
    Ampavg(:,i) = nanmean(Amp(groupind(i):groupind(i+1)-1));
    phiavg(i) = nanmean(phi(groupind(i):groupind(i+1)-1));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting Activity and Sleep Traces
sleeptime=(1:size(sleepdata,1)/sleepbin)/sleepsr; %generates a timeseries for sleepbinning

%plot sleep propensity in 30min bins
daysLDvec=repelem(0:(daysLD-1),4);
daylightx=[0,0,0.5,0.5]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfillx=repmat(daylightx,1,daysLD);
dayfillx=daysLDvec + dayfillx;
daylighty=[0,1,1,0]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfilly=repmat(daylighty,1,daysLD);

daysDDvec=repelem(daysLD:last-1,4);
darklightx=[0,0,0.5,0.5]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
darkfillx=repmat(darklightx,1,last-daysLD);
darkfillx=daysDDvec + darkfillx;
darklighty=[0,1,1,0]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
darkfilly=repmat(darklighty,1,last-daysLD);

clear i j k l m
save('Sleep_variables.mat', '-mat');

% Individual Activity and Binned Sleep Traces
    parfor k=1:animalnos
    tkcircindplot(k);
    end

% Line Averaged Activity and Binned Sleep Traces
    parfor k=group
    tkcircgroupplot(k);
    end
    
    % if there are less than eight lines this will saveas them all on a single
% axis for visual comparison
if groupnumbers<=8
% figure    
  subplot(2,1,1)
    Ylim=max(max(activelineavg));
    fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
    hold on
    fill(darkfillx,darkfilly*Ylim,'k','FaceAlpha',0.1)
   h1 = plot(time,activelineavg,'LineWidth',1);
    ylabel('Activity (cnts)')
    if Ylim > 1
        ylim([0 Ylim])
    else
        ylim([0 1])
    end
    legend(h1,groupnames,'Location','northwest')
    title(strcat(foldername,' Activity and Sleep Profiles '));
    hold off
  subplot(2,1,2)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    fill(darkfillx,darkfilly*100,'k','FaceAlpha',0.1)
    plot(sleeptime,sleepproblineavg,'LineWidth',1);
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
    savefig(gcf,strcat('Locomotor and Sleep Trace Comparisons by genotype ',foldername,'.fig'));
    saveas(gcf,strcat('Locomotor and Sleep Trace Comparisons by genotype ',foldername,'.pdf'),'pdf');
end

%% Plot sleep probability in LD vs DD for all lines
if strcmpi(DD,'Y') == 1
    for i=group
    sleepprobavg(:,i) = nanmean(sleepprob(groupind(i):groupind(i+1)-1));
    sleepLDavg(i) = nanmean(sleepLD(groupind(i):groupind(i+1)-1));
    sleepLDdayavg(i) = nanmean(sleepLDday(groupind(i):groupind(i+1)-1));
    sleepLDnightavg(i) = nanmean(sleepLDnight(groupind(i):groupind(i+1)-1));
        if strcmpi(DD,'Y') == 1
        sleepDDavg(i) = nanmean(sleepDD(groupind(i):groupind(i+1)-1));
        sleepDDdayavg(i) = nanmean(sleepDDday(groupind(i):groupind(i+1)-1));
        sleepDDnightavg(i) = nanmean(sleepDDnight(groupind(i):groupind(i+1)-1));
        end
    end

    if nosperline > 1
        if max(sleepLDavg)>max(sleepDDavg)
        X=0:1:max(sleepDDavg);
        Y=0:1:max(sleepDDavg);
        else
        X=0:1:max(sleepLDavg);
        Y=0:1:max(sleepLDavg); 
        end

    figure
    scatter(sleepLDavg,sleepDDavg,'b');
    hold on
    plot(X,Y,'r')
    xlabel('Average Total Sleep Time (min) During LD')
    ylabel('Average Total Sleep Time (min) In Constant Darkness')
    title(strcat(foldername,' Total Daily Sleep Time by genotype'))
    xlim([0 max(sleepLDavg)+1])
    ylim([0 max(sleepDDavg)+1])
    savefig(strcat(foldername,' Daily TST LD vs DD Scatter Plot','.fig'))
    saveas(gcf,strcat(foldername,' Daily TST LD vs DD Scatter Plot','.pdf'),'pdf')
    end

    % Plot histograms for TST in LD and DD for screen
    if groupnumbers>10
        figure
        subplot(1,2,1)
        histogram(sleepLDavg,10);
        xlabel('Total Sleep Time')
        title('L:D')
        subplot(1,2,2)
        histogram(sleepDDavg,10);
        xlabel('Total Sleep Time')
        title('D:D')
        saveas(gcf,strcat(foldername,' Daily TST Histograms','.pdf'),'pdf')
    end
end
save('Sleep_variables.mat', '-mat');

%% Extraneous Plotting

if groupnumbers>10
    boxp='compact';
else
    boxp='traditional';
end

%boxplots for all lines
%Boxplots of LD and DD data
if strcmpi(DD,'Y') == 1
        positionLD=0.8:1:groupnumbers-0.2;
        positionDD=1.2:1:groupnumbers+0.2;
    %Total Sleep Time
figure
    boxplot(sleepLD,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    hold on
    boxplot(sleepDD,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Total Daily Sleep Time by genotype'))
    ylim([0 max([max(sleepLD) max(sleepDD)])+1])
        box_vars = findall(gca,'Tag','Box');
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Daily TST by genotype','.pdf'),'pdf')
    
    boxplot(sleepLDday,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    hold on
    boxplot(sleepDDday,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Total Daytime Sleep Time by genotype'))
    ylim([0 max([max(sleepLDday) max(sleepDDday)])+1])
        box_vars = findall(gca,'Tag','Box');
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Daytime TST by genotype','.pdf'),'pdf')
    
    boxplot(sleepLDnight,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    hold on
    boxplot(sleepDDnight,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
        set(gca,'XTickLabel',{' '})  % Erase xlabels
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Total Nighttime Sleep Time by genotype'))
    ylim([0 max([max(sleepLDnight) max(sleepDDnight)])+1])
        box_vars = findall(gca,'Tag','Box');
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Nighttime TST by genotype','.pdf'),'pdf')
    
    boxplot(DNratioLD,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    xticks('manual')
    hold on
    boxplot(DNratioDD,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
        set(gca,'XTickLabel',{' '})  % Erase xlabels
    hold off
    xlabel('Line Nos')
    ylabel('Day/Night Sleep Time Ratio')
    xtickangle(45)
    title(strcat(foldername,'Day/Night Sleep Time Ratio'))
    ylim([0 max([max(DNratioLD) max(DNratioDD)])])
        box_vars = findall(gca,'Tag','Box');
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Day Night TST Ratio by genotype','.pdf'),'pdf')

    % Plot histograms for Sleep in LD and DD across the genotype (consider
    if groupnumbers>10
    subplot(1,2,1)
    histfit(sleepLDavg,10);
    xlabel('Total Sleep Time')
    title('L:D')
    subplot(1,2,2)
    histfit(sleepDDavg,10);
    xlabel('Total Sleep Time')
    title('D:D')
    print(strcat(foldername,' Total Daily Sleep Time Histograms','.pdf'),'-dpdf')
    end
    
    % Sleep Bout Count
figure
    boxplot(wakeboutnos(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
        set(gca,'XTickLabelRotation',45)
        hold on
    boxplot(wakeboutnos(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
        set(gca,'XTickLabel',{' '})  % Erase xlabels
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Nos (cnts)')
    xtickangle(45)
    title(strcat(foldername,'Sleep Bout Nos by genotype'))
    ylim([0 max([max(sleepboutnos(LDday,:)) max(sleepboutnos(DDday,:))+ max([max(sleepboutnos(LDday,:)) max(sleepboutnos(DDday,:))])*0.1])])
        box_vars = findall(gca,'Tag','Box');        
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Nos of Sleep Bouts by genotype','.pdf'),'pdf')
    
    % Wake Bout Length
    figure
    boxplot(wakeboutavg(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    hold on
    boxplot(wakeboutavg(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Wake Bout Length (min)')
    xtickangle(45)
    title(strcat(foldername,'Wake Bout Length by genotype'))
    ylim([0 max([max(sleepboutnos(LDday,:)) max(sleepboutnos(DDday,:))+ max([max(sleepboutnos(LDday,:)) max(sleepboutnos(DDday,:))])*0.1])])
        box_vars = findall(gca,'Tag','Box');
                hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Wake Bout Length by genotype','.pdf'),'pdf')
    
    % Sleep Bout Nos Ratio
    figure
    boxplot(sleepboutnosratio(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    hold on
    boxplot(sleepboutnosratio(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Nos Day/Night Ratio')
    xtickangle(45)
    title(strcat(foldername,'Sleep Bout Nos Day/Night Ratio by genotype'))
    ylim([0 max([max(sleepboutnosratio(LDday,:)) max(sleepboutnosratio(DDday,:))])*1.1])
        box_vars = findall(gca,'Tag','Box');
                hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Sleep Bout Nos Day-Night Ratio by genotype','.pdf'),'pdf') 
    
    % Sleep Bout Length Ratio
    figure
    boxplot(sleepboutavgratio(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    hold on
    boxplot(sleepboutavgratio(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Length Day/Night Ratio')
    xtickangle(45)
    title(strcat(foldername,'Sleep Bout Length Day/Night Ratio by genotype'))
    ylim([0 max([max(sleepboutavgratio(LDday,:)) max(sleepboutavgratio(DDday,:))])*1.1])
        box_vars = findall(gca,'Tag','Box');
                hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Sleep Bout Length Day-Night Ratio by genotype','.pdf'),'pdf') 
    
    %Activity and sleep onsets plotting by genotype/line    
    figure
    polarscatter(activityonsets(1,:)/180*pi,group,'FaceColor','magenta');
    hold on
    polarscatter(activityonsets(2,:)/180*pi,group,'FaceColor','cyan');
    polarscatter(sleeponsets(1,:)/180*pi,group,'FaceColor','green');
    polarscatter(sleeponsets(2,:)/180*pi,group,'FaceColor','red');
    hold off
    ax=gca;
    ax.ThetaZeroLocation = 'left';
    ax.ThetaDir = 'clockwise';
    legend('Activity Onset LD','Activity Onset DD','Sleep Onset LD','Sleep Onset DD')
    saveas(gcf,strcat(foldername,' Activity and Sleep Onsets Polar Plot','.pdf'),'pdf')
    
    % Circadian parameter plotting
    boxplot(per,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Circadian Period (hrs)')
    title(strcat(foldername,' Free Running Rhythm (tau)'))
    ylim([min(per)-min(per)*0.05 max(per)*1.05])
    saveas(gcf,strcat(foldername,' Circadian Tau by genotype','.pdf'),'pdf')
    
    boxplot(M,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Circadian Mesor (min)')
    title(strcat(foldername,' Mesor'))
    ylim([min(M)-min(M)*0.05 max(M)*1.05])
    saveas(gcf,strcat(foldername,' Circadian Mesor by genotype','.pdf'),'pdf')
    
    boxplot(Amp,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Circadian Amplitude (min)')
    title(strcat(foldername,' Amplitude'))
    ylim([min(Amp)-min(Amp)*0.05 max(Amp)*1.05])
    saveas(gcf,strcat(foldername,' Circadian Amplitude by genotype','.pdf'),'pdf')
    
    phi_d=phi*180/pi+360;
    boxplot(phi_d,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Circadian Acrophase (degrees)')
    title(strcat(foldername,' Acrophase'))
    ylim([min(phi_d)-min(phi_d)*0.05 max(phi_d)*1.05])
    saveas(gcf,strcat(foldername,' Circadian Acrophase by genotype','.pdf'),'pdf')
    
    if groupnumbers>10 && strcmpi(DD,'Y') == 1
    % Plotting wakefulness bout nos versus bout length
    figure
    gscatter(wakeboutavg(LDday,:),wakeboutnos(LDday,:),grouping,'r','o')
    hold on
    gscatter(wakeboutavg(DDday,:),wakeboutnos(DDday,:),grouping,'k','x')
    xlabel('Wake Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    xtickangle(45)
    title(strcat(foldername,' Wake Bout Length vs Number by genotype'))
    legend('off')
    saveas(gcf,strcat(foldername,' Wake Bout Length Vs Nos by genotype','.pdf'),'pdf')
      % Plotting sleep bout nos versus bout length
    figure
    gscatter(sleepboutavg(LDday,:),wakeboutnos(LDday,:),grouping,'r','o')
    hold on
    gscatter(sleepboutavg(DDday,:),wakeboutnos(DDday,:),grouping,'k','x')
    xlabel('Sleep Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    xtickangle(45)
    title(strcat(foldername,' Sleep Bout Length vs Number by genotype'))
        legend('off')
    saveas(gcf,strcat(foldername,' Sleep Bout Length Vs Nos by genotype','.pdf'),'pdf')
    
    if groupnumbers>10
    figure
    subplot(4,1,1)
    hist(peravg,10);
    xlabel('Circadian Period (hrs)')
    title('Tau')
    subplot(4,1,2)
    hist(Mavg,10);
    xlabel('Sleep Mesor (min)')
    title('Mesor')
    subplot(4,1,3)
    hist(Ampavg,10);
    xlabel('Circadian Amplitude (min)')
    title('Amplitude')
    subplot(4,1,4)
    hist(phiavg,10);
    xlabel('Circadian Phase (degrees)')
    title('Phi')
    saveas(gcf,strcat(foldername,' Free Running Rhythms Histograms','.pdf'),'pdf')
    end
    end
end

close all;
save('Sleep_variables.mat', '-mat');
clearvars;
end