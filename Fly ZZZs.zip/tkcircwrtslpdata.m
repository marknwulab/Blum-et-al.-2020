function []=tkwritescreendata(varargin)
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
if exist('Sleep_variables.mat')==2
    load('Sleep_variables.mat', '-mat');
end
if exist('Sleep_zscores.mat')==2
    load('Sleep_zscores.mat', '-mat');
end
if exist('Sleep_ANOVA.mat')==2
    load('Sleep_ANOVA.mat')
end
 	
% This code increases the speed of the xlsxwrite function when used in loops
% or multiple times. The problem with the original function is that it opens 
% and closes the Excel server every time the function is used. 
% To increase the speed I have just edited the original function by removing 
% the server open and close function from the xlsxwrite function and moved 
% them outside of the function. To use this first run the following code 
% which opens the activex server and checks to see if the file already exists (creates if it doesnt):
warning('off','MATLAB:xlswrite:AddSheet')

Excel = actxserver ('Excel.Application');
File=fullfile(pwd,strcat(filename,' Raw Sleep Data.xlsx'));
if ~exist(File,'file')
    ExcelWorkbook = Excel.Workbooks.Add;
    ExcelWorkbook.SaveAs(File);
    ExcelWorkbook.Close(false);
end

invoke(Excel.Workbooks,'Open',File);

linenos={'Line Nos'};
genotype={'Genotype'};
subject={'n='};
fil={'files'};
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),linenos,'Line Legend', 'A1');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),group','Line Legend','A2')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),genotype,'Line Legend','B1');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupnames','Line Legend','B2');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),subject,'Line Legend','C1');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupsize','Line Legend','C2');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),fil,'Line Legend','D1');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),textfilenamesgp,'Line Legend','D2');

xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),Headtext,'Sleep Data');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),textfilenames,'Sleep Data','B1')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),time','Sleep Data','A4');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),sleepdata,'Sleep Data','B4');

xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),Headtext,'Sleep Probability');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),textfilenames,'Sleep Probability','B1')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),sleeptime','Sleep Probability','A4');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),sleepprob,'Sleep Probability','B4');

xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),Headtext,'Avg Sleep Probability');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupnames,'Avg Sleep Probability','B1')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupsize,'Avg Sleep Probability','B2')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),sleeptime','Avg Sleep Probability','A4');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),sleepproblineavg,'Avg Sleep Probability','B4');

xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),Headtext,'Activity');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),textfilenames,'Activity','B1')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),time','Activity','A4');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),active,'Activity','B4');

xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),Headtext,'Avg Activity');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupnames,'Avg Activity','B1')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupsize,'Avg Activity','B2')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),time','Avg Activity','A4');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),activelineavg,'Avg Activity','B4');

xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),{'Group'},'Group sizes','A1');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),{'n='},'Group sizes','A2');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),{'nos of dead'},'Group sizes','A3');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),{'nos insuf dep'},'Group sizes','A4');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupnames,'Group sizes','B1')
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupsize,'Group sizes','B2');
xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),deadsize,'Group sizes','B3');

if exist('Sleep_zscores.mat')==2
    warning('off','MATLAB:xlswrite:AddSheet')
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),{'Variables'},'Screen Group Variables');
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupnames,'Screen Group Variables','B1')
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),varnames','Screen Group Variables','A2');
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),groupvar,'Screen Group Variables','B2');

    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),{'Variables'},'Screen Hits');
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),{'Lines'},'Screen Hits','B1')
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),varnames','Screen Hits','A2');
    for ii=1:length(varnames)
        varplace=strcat('B',num2str(ii+1));
        xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),Zedhits{1,ii},'Screen Hits',varplace);
    end
end

if exist('Sleep_ANOVA.mat')==2
        warning('off','MATLAB:xlswrite:AddSheet')
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),{'Variables'},'Screen Variables');
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),textfilenames,'Screen Variables','B1')
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),varnames','Screen Variables','A2');
    xlswrite1(strcat(filename,' Raw Sleep Data.xlsx'),varcell,'Screen Variables','B2');
end

invoke(Excel.ActiveWorkbook,'Save');
Excel.Quit
Excel.delete
clear Excel
% system('taskkill /F /IM EXCEL.EXE');
end