%Take outputs from tksleepdep and perform z-scoring, outlier detection,
%multivariate analysis, PCA, and clustering analysis for screening purposes

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=tkdepplot(k)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
if exist ('SleepDep_variables.mat') == 2
load('SleepDep_variables.mat', '-mat');
else
error('No deprivation data is calculated for this dataset')
end

t=[0 2 4 6 8 10 12];
t2=t/24+(recoday+1);
subplot(2,1,1)
h1=plot(deptime(sleepsr/2:sleepsr),cumsleeplostperclineavg(sleepsr/2:sleepsr,k)+100,'LineWidth',1);
%     set(h, {'MarkerFaceColor'}, get(h,'Color'));
    legend(h1,groupnames(k),'Location','northwest')
    xlabel('Time (hrs post deprivation)')
    ylabel('Sleep Recovered (%)')
    xticks(t2)
    xticklabels(t)
    ylim([0 50])
subplot(2,1,2)
    plot(deptime,cumsleeplostperclineavg(:,k),'k','LineWidth',2)
    xlabel('Time (days)')
    ylabel('Sleep Lost (%)')
    print(gcf,strcat('Line Avg ',groupnames{k},' Percent Sleep Recovered and Lost Trace','.pdf'),'-dpdf');
end