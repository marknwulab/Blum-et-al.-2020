%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [groupnumbers] = tkfileload(varargin)
%% Load files into data array
load('Variables.mat', '-mat')

% getting folder name
currentDirectory = pwd;
[upperPath, foldername, ~] = fileparts(currentDirectory); 

%Getting file names
textfiles=dir('*.txt');
% data=zeros(1,length(textfiles));
animalnos=length(textfiles);

if isnan(groupnos)==0
    if numel(groupnos)==1 && rem(animalnos/groupnos,1)~=0
        error('number of files does not match groupnos variable')
    elseif numel(groupnos)>1 && animalnos~=sum(groupnos)
        error('number of files does not match groupnos variable')
    end
end

if isempty(grouptype)==1
    grouptype={'C'};
end

if numel(grouptype)==1 && numel(grouptype)~=numel(groupnos)
    grouptype=cellstr(repmat(grouptype,numel(groupnos),1))';
end
        

%%%%Need to rewrite this section since we can now calculate most of these
%%%%parameters from the filenames (see section starting at line 27) Might
%%%%also need to dig into tknumperline to sort that out, may be redundant.
if numperline >= 1
    if numel(numperline)==1
    nosperline=numperline;
    groupnumbers=ceil(animalnos/nosperline);
    group=1:groupnumbers;
    grouping=repelem(group,nosperline);
    groupind=find(diff([-inf grouping inf])~=0);
    else
    nosperline=numperline;
    groupnumbers=numel(nosperline);
    group=1:groupnumbers;
    grouping=repelem(group,nosperline);
    groupind=find(diff([-inf grouping inf])~=0);
    end
else
    nosperline=animalnos;
    groupnumbers=1;
    group=1;
    grouping=ones(1,animalnos);
    groupind=find(diff([-inf grouping inf])~=0);
end

for i = 1:animalnos;
    texnam = textfiles(i).name;
    datum = importdata(texnam);
    if isstruct(datum)==0
    data{:,i}= datum(5:end,1);  
    elseif isstruct(datum)==1
        if size(datum.textdata,1)>4
        data{:,i}= str2double(datum.textdata(5:end,1));
        elseif size(datum.textdata,1)==1;
        data{:,i}=datum.data(4:end,1);
        end
    end
end

%generating filename(s) and groupname(s) based on filenames and identified
%group numbers
filename=foldername;
tfn=struct2cell(textfiles);
textfilenames=tfn(1,:);
 for i=group
     groupnames{i}=textfilenames{groupind(i)}(1:end-13);
 end
% need some code to introduce Line Numbers as groupnames if the filename
% are not unique prior to the "Ct", i.e. MyRun of something similar across all files
if numel(unique(groupnames))==1
    clear groupnames
    groupnames=num2cell(group);
    groupnames=cellfun(@num2str, groupnames, 'UniformOutput', false);
end
 
 
% make all NaNs into zeros
  [nm, ~] = size(data);
  parfor im = 1:nm
       data{im}(isnan(data{im}))=0;
  end

if exist('first')==0;
first=input('Enter the first day of the record to use');
last=input('Enter the last day of the record to use');
end

%trim full records to data of interest
trim=(first-1)*sr+1:last*sr;
datatrim=zeros(length(trim),animalnos);
if trim>size(data{1,1},1)
    error('Please recheck the day nos input for "first" and "last"')
end

parfor i = 1:animalnos
    if numel(data{1,i})<numel(trim)
        error('Please check that all monitor files are long enough')
    end
datatrim(:,i)=data{1,i}(trim,:);
end
% input a vector for the time (in days)
time=((1:length(datatrim(:,1)))/sr)+1;

%code to identify dead animals based on locomotor activity of the last full day, will replace calculated  values with NaN before averaging for each line
quiescent=zeros(1,animalnos);
lastday=(End-1)*sr+1:End*sr;
parfor h=1:animalnos
    quiescent(h)=sum(datatrim(lastday,h));
    unloaded(h)=mean(datatrim(:,h));
end

if strcmpi(ALL,'Y') == 1
        deadind=find(quiescent<actthresh); %provides indices of all dead flies according to actthresh criteria
    else
        deadind=find(unloaded<0.01); %provides indices of all unloaded tubes assuming the mean should approach zero.
end


      
% Excel Headers
Headlin={'Line'; NaN; 'Avg Period'; NaN;'St Dev Period'; NaN; 'Avg Amplitude'; NaN; 'St Dev Amplitude'};
Headanim={'Animal'; NaN; 'Period'; NaN;'Amplitude'};
Headtext={'Animal';'n=';'Time'};

clear i
save('file_variables.mat', '-mat');