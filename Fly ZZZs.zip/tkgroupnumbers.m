% Determine the number of groups based on unique text prefixes (used with fly_ZZZZs.m

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use, unless by explicit permission from the  %%
% copyright holder.                                               %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [groupnos]=tkgroupnumbers(varargin)
%getting folder name
currentDirectory = pwd;
[upperPath, foldername, ~] = fileparts(currentDirectory); 

%Getting file names
textfiles=dir('*.txt');
% data=zeros(1,length(textfiles));
animalnos=length(textfiles);

filename=foldername;
tfn=struct2cell(textfiles);
textfilenames=tfn(1,:);
for i=1:animalnos
     grupnam{i}=textfilenames{i}(1:end-13);
end
[uniqnames,bnam,grouping]=unique(grupnam);
groupnos=histcounts(grouping);
end 