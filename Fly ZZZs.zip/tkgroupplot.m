%Take outputs from tksleepdep and perform z-scoring, outlier detection,
%multivariate analysis, PCA, and clustering analysis for screening purposes

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=tkgroupplot(k)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
if exist ('SleepDep_variables.mat') == 2
load('SleepDep_variables.mat', '-mat');
else
load('Sleep_variables.mat', '-mat');
end

subplot(2,1,1)
    Ylim=max(activelineavg(:,k));
    fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
    hold on
    if strcmpi(DEP,'Y') ==1
    fill(depfillx,depfilly*Ylim,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1;
        fill(pulse2fillx,pulse2filly*Ylim,'r','FaceAlpha',0.5)    
        end
    end
    plot(time,activelineavg(:,k),'k','LineWidth',2);
    ylabel('Activity (cnts)')
    if Ylim > 1
        ylim([0 Ylim])
    else
        ylim([0 1])
    end
    title(strcat(groupnames{k},' Activity and Sleep Profiles'));
    hold off
    subplot(2,1,2)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    if strcmpi(DEP,'Y') ==1
    fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1;
        fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
        end
    end
    plot(sleeptime,sleepproblineavg(:,k),'k','LineWidth',2);
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
    print(gcf,strcat('Line Avg ',groupnames{k},' Locomotor and Sleep Trace','.pdf'),'-dpdf');