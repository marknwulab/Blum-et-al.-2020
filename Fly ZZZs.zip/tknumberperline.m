% Processes the groupnos variable input from fly_ZZZs.m

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use, unless by explicit permission from the  %%
% copyright holder.                                               %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [numperline]=tknumberperline(varargin)
    if isempty(varargin)==1
    lineprompt1 = 'Is there more than one genotype (Y/N) [N]: ';
    linum1=input(lineprompt1, 's');
        if isempty(linum1)
            linum1 = 'N';
        end

        if strcmpi(linum1,'N')==1
           numperline=NaN;
        else
        lineprompt2 = 'Is the number of animals per group equally distributed (Y/N) [Y]: ';
        linum2=input(lineprompt2, 's');
        if isempty(linum2)
            linum2 = 'Y';
        end
        end

    if strcmpi(linum2,'Y')
    numperline=input('How many animals per group?');
    else
    error('Please input a vector [x,y,z,aa,etc.] with the number of lines per group when you call this function');
    end
    elseif isnan(varargin{1})==1
    numperline=NaN;
    elseif isempty(varargin{1})==0
    numperline=varargin{1};
    end
end