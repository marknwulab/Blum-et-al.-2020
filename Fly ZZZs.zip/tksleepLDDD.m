%Run and plot sleep data for locomotor traces when there is LD followed by DD
%lighting conditions in the recording

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=tksleepLDDD(varargin)

load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');

% Generates sliding window to define lack of activity as sleep
sleepsum=zeros(size(datatrim,1)-sleepdef,animalnos);
sleepsumend=ones(sleepdef,animalnos);
for i=1:animalnos;
   for j=1:size(datatrim,1)-sleepdef;
    sleepsum(j,i)=sum(datatrim(j:(j-1)+sleepdef,i));
   end
end
sleepsum=[sleepsum;sleepsumend]; %just padding the last five minutes with no sleep and very low activity

%locate all the sleep epochs
sleepind=find(~sleepsum); %locates all the sleep epochs
sleepdata=zeros(size(datatrim,1),animalnos);
sleepdata(sleepind)=1;
sleepdata(:,deadind)=NaN; %Remove all dead animals from sleep analysis
active=datatrim;
active(:,deadind)=NaN; %Remove all dead animals from activity analysis

%finding sleep probability per bin
for i=1:animalnos;
   for j=1:size(sleepdata,1)/sleepbin;
    sleepprob(j,i)=sum(sleepdata((sleepbin*j)-sleepbin+1:sleepbin*j,i))/sleepbin*100;
   end
end

%Generating group average for activity and sleep traces
for i=group
        activelineavg(:,i)=nanmean(datatrim(:,((i-1)*nosperline+1):i*nosperline),2);
        sleepproblineavg(:,i)=nanmean(sleepprob(:,((i-1)*nosperline+1):i*nosperline),2);
end

%Total Sleep time per day and phase distribution
for i=1:animalnos;
    sleepLD(i)=sum(sleepdata((LDday-1)*sr+1:LDday*sr,i));
    sleepprobLD=sleepLD./sr*100;
    sleepDD(i)=sum(sleepdata((DDday-1)*sr+1:DDday*sr,i));
    sleepprobDD=sleepDD./sr*100;
end

groupsind=isnan(sleepdata(1,:));
groups=ones(1,animalnos).*~groupsind;
temp=zeros(1,animalnos);temp(deadind)=1;deadgroups=temp;
    if isempty(grouptype)==0
    temp=zeros(1,animalnos);temp(depind)=1;depgroups=temp;
    else
    depgroups=ones(1,animalnos);
    end
groupsize=zeros(1,groupnumbers);deadsize=zeros(1,groupnumbers);depsize=zeros(1,groupnumbers);
    for i=group
    groupsize(i)=sum(groups(groupind(i):groupind(i+1)-1));
    deadsize(i)=sum(deadgroups(groupind(i):groupind(i+1)-1));
    depsize(i)=sum(depgroups(groupind(i):groupind(i+1)-1));
    end

%Plotting sleep data
sleeptime=((1:size(sleepdata,1)/sleepbin)/sleepsr)+1; %generates a timeseries for sleepbinning

for i=group;
sleepprobavg(:,i) = nanmean(sleepprob(((i-1)*nosperline+1):i*nosperline));
sleepLDavg(i) = nanmean(sleepLD(((i-1)*nosperline+1):i*nosperline));
sleepDDavg(i) = nanmean(sleepDD(((i-1)*nosperline+1):i*nosperline));
end

%boxplots for all lines
figure
boxplot(sleepLD,grouping(1:animalnos),'plotstyle','compact');
xlabel('Line Nos')
ylabel('Total Sleep Time (min)')
title('L:D Total Daily Sleep Time by line')
ylim([0 max(sleepLD)+1])
print(strcat(foldername,' LD Total Daily Sleep Time by line','.pdf'),'-dpdf')

figure
boxplot(sleepDD,grouping(1:animalnos),'plotstyle','compact');
xlabel('Line Nos')
ylabel('Total Sleep Time (min)')
title('D:D Total Daily Sleep Time by line')
ylim([0 max(sleepDD)+1])
print(strcat(foldername,' DD Total Daily Sleep Time by line','.pdf'),'-dpdf')

% Plot sleep probability in LD vs DD for all lines
if nosperline > 1
if max(sleepLDavg)>max(sleepDDavg)
X=0:1:max(sleepDDavg);
Y=0:1:max(sleepDDavg);
else
X=0:1:max(sleepLDavg);
Y=0:1:max(sleepLDavg); 
end

figure
scatter(sleepLDavg,sleepDDavg,'b');
hold on
plot(X,Y,'r')
xlabel('Average Total Sleep Time (min) During LD')
ylabel('Average Total Sleep Time (min) In Constant Darkness')
title('Total Daily Sleep Time by line')
ylim([0 max(sleepDDavg)+1])
xlim([0 max(sleepLDavg)+1])
print(strcat(foldername,' Total Daily Sleep Time Scatter Plot','.pdf'),'-dpdf')
end

% Plot histograms for Sleep in LD and DD
% figure
if isnan(numperline) == 0
subplot(1,2,1)
histfit(sleepLDavg,10);
xlabel('Total Sleep Time')
title('L:D')
subplot(1,2,2)
histfit(sleepDDavg,10);
xlabel('Total Sleep Time')
title('D:D')
print(strcat(foldername,' Total Daily Sleep Time Histograms','.pdf'),'-dpdf')
end

%plot sleep propensity in 30min bins
daysLDvec=repelem(1:daysLD,4);
daylightx=[0,0,0.5,0.5]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfillx=repmat(daylightx,1,daysLD);
dayfillx=daysLDvec + dayfillx;
daylighty=[0,1,1,0]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfilly=repmat(daylighty,1,daysLD);

save('Sleep_variables.mat', '-mat');

% Individual Activity and Binned Sleep Traces
    parfor k=1:animalnos
    tkindplot(k);
    end

% Line Averaged Activity and Binned Sleep Traces
    parfor k=group
    tkgroupplot(k);
    end

save('Sleep_variables.mat', '-mat');

close all;
end