%Run and plot sleep data from Trikinetics locomotor monitors, including
%individual and grouped analysis

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%  to do: 
% -split into sleepdep and sleepLDDD functions

function []=tksleepdep(varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
%  preallocating for speed
dlen=size(datatrim,1);
slen=dlen/sleepbin;

% Generates sliding window to define lack of activity as sleep
sleepsum=zeros(size(datatrim,1)-sleepdef,animalnos);
sleepsumend=ones(sleepdef,animalnos);
for i=1:animalnos;
   for j=1:size(datatrim,1)-sleepdef;
    sleepsum(j,i)=sum(datatrim(j:(j-1)+sleepdef,i));
   end
end
sleepsum=[sleepsum;sleepsumend]; %just padding the last five minutes with no sleep and very low activity

%locate all the sleep epochs and generates sleepdata logical matrix
sleepind=find(~sleepsum); %locates all the sleep epochs
sleepdata=zeros(size(datatrim));
sleepdata(sleepind)=1; %#ok<FNDSB> %
sleepdata(:,deadind)=NaN; %Remove all dead animals from sleep analysis
active=datatrim;
active(:,deadind)=NaN; %Remove all dead animals from activity analysis


% distcomp.feature( 'LocalUseMpiexec', true )
%locate all sleep/wake transitions
krn=[1 -1];
transitions=zeros(dlen+1,animalnos);
wtsind=cell(1,animalnos);
stwind=cell(1,animalnos);
parfor k=1:animalnos
    transitions(:,k)=conv(krn,sleepdata(:,k));
    wtsind{1,k}=find(transitions(:,k)==1); %all wake to sleep transitions
    stwind{1,k}=find(transitions(:,k)==-1); %all sleep to wake transitions
end

%% Sleep Analysis
if strcmp(DEP,'Y') == 1;
% generating index to remove all animals without sufficient nighttime sleep deprivation
    nightsleeppredep=zeros(1,animalnos);
    nightsleepdep=zeros(1,animalnos);
    basetrim=(baseday-0.5)*sr+1:(baseday)*sr;
    deptrim=(depday-0.5)*sr:(depday)*sr-1;
    parfor i=1:animalnos;
        nightsleeppredep(i)=sum(sleepdata(basetrim,i));
        nightsleepdep(i)=sum(sleepdata(deptrim,i));
    end
% Remove animals (from exp groups) which do not meet sleep dep threshold
    if isempty(grouptype)==0;  
        if isnan(numperline)==1;
            groupdepind=ones(1,animalnos);
        elseif exist('grouptype') == 1
            groupdepind=repelem(strcmpi('E',grouptype),nosperline);
        else
            groupdepind=zeros(1,animalnos);
        end

        if numel(groupdepind)~=animalnos
            error('please recheck the input for "grouptype"')
        end
    depeffect=100-(nightsleepdep./nightsleeppredep.*100);
    depind=find(depeffect<depthresh & groupdepind==1);
    active(:,depind)=NaN;
    sleepdata(:,depind)=NaN;
    end
end
% Calculating the final group sizes after accounting for dead animals and
% those that lack appropriate deprivation
groupsind=isnan(sleepdata(1,:));
groups=ones(1,animalnos).*~groupsind;
temp=zeros(1,animalnos);temp(deadind)=1;deadgroups=temp;
    if isempty(grouptype)==0
    temp=zeros(1,animalnos);temp(depind)=1;depgroups=temp;
    else
    depgroups=ones(1,animalnos);
    end
groupsize=zeros(1,groupnumbers);deadsize=zeros(1,groupnumbers);depsize=zeros(1,groupnumbers);
    for i=group
    groupsize(i)=sum(groups(groupind(i):groupind(i+1)-1));
    deadsize(i)=sum(deadgroups(groupind(i):groupind(i+1)-1));
    depsize(i)=sum(depgroups(groupind(i):groupind(i+1)-1));
    end


% finding sleep probability per bin
sleeptime=((1:size(sleepdata,1)/sleepbin)/sleepsr)+1; %generates a timeseries for sleepbinning
sleepprob=zeros(slen,animalnos);
sb=sleepbin;
parfor i=1:animalnos;
   sd=sleepdata(:,i)
   for j=1:slen;
   sbtrim=(sb*j)-sb+1:sb*j;
   sleepprob(j,i)=sum(sd(sbtrim))/sb*100;
   end
end

%Total Sleep Time (TST) for designated days in LD and DD
if strcmp(DD,'Y') == 1;
    LDtrim=(LDday-1)*sr+1:LDday*sr;
    DDtrim=(DDday-1)*sr+1:DDday*sr;
    parfor i=1:animalnos;
    sleepLD(i)=sum(sleepdata(LDtrim,i));
    sleepDD(i)=sum(sleepdata(DDtrim,i));
    end
sleepprobLD=sleepLD./sr*100;
sleepprobDD=sleepDD./sr*100;
end

%TST and day/night analysis for baseline, deprivation, recovery, and during
%the pulse
if strcmp(DEP,'Y') == 1;
    for i=1:animalnos;
        %baseline day
        sleeppredep(i)=sum(sleepdata((baseday-1)*sr+1:(baseday)*sr,i));
        daysleeppredep(i)=sum(sleepdata((baseday-1)*sr+1:(baseday-0.5)*sr,i));
        nightsleeppredep(i)=sum(sleepdata((baseday-0.5)*sr+1:(baseday)*sr,i));
        %deprivation day
        sleepdep(i)=sum(sleepdata((depday-1)*sr:(depday)*sr-1,i));
        daysleepdep(i)=sum(sleepdata((depday-1)*sr:(depday-0.5)*sr-1,i));
        nightsleepdep(i)=sum(sleepdata((depday-0.5)*sr:(depday)*sr-1,i));
        %recovery day
        sleepreco(i)=sum(sleepdata((recoday-1)*sr:recoday*sr-1,i));
        daysleepreco(i)=sum(sleepdata((recoday-1)*sr:(recoday-0.5)*sr-1,i));
        nightsleepreco(i)=sum(sleepdata((recoday-0.5)*sr:recoday*sr-1,i));

        %Sleep recovery epoch (defined by recobin and/or recobinpulse)
        %   currently this is total sleep during recovery period, 
        %   might consider changinig this to reflect extra sleep above baseline on recovery day
        if strcmpi(PULSE,'Y') == 1
            sleeprecobin(i)=sum(sleepdata(((depday-1)+(pulse/24))*sr:((depday-1)+(pulse/24)+(recobinpulse/24))*sr-1,i));
            else
            sleeprecobin(i)=sum(sleepdata((recoday-1)*sr:((recoday-1)+(recobin/24))*sr-1,i));
        end
        %Sleep Rebound
        if strcmpi(PULSE,'Y') == 1
            sleepreboundbin(i)=sum(sleepdata(((depday-1)+(pulse/24))*sr:((depday-1)+(pulse/24)+(recobinpulse/24))*sr-1,i))-sum(sleepdata(((baseday-1)+(pulse/24))*sr:((baseday-1)+(pulse/24)+(recobinpulse/24))*sr-1,i));
            else
            sleepreboundbin(i)=sum(sleepdata((recoday-1)*sr:((recoday-1)+(recobin/24))*sr-1,i))-mean([sum(sleepdata((baseday-1)*sr+1:((baseday-1)+(recobin/24))*sr-1,i)) sum(sleepdata((depday-1)*sr:((depday-1)+(recobin/24))*sr-1,i))]);
        end

        %calculating time to maximal sleep after activation/deprivation (or
        %alternatively consider plotting slope of rebound activation? Need
        %to rewrite this to work with overnight sleep dep and not just
        %pulse
        if strcmpi(PULSE,'Y') == 1 
        sleeppulse(:,i)=sleepprob(((depday-1)+(pulse/24))*(sr/30):((depday-1)+(pulse/24)+(recobinpulse/24))*(sr/30)-1,i);
            if sum(sleeppulse(:,i))>=1
                reblatind(i)=find(sleeppulse(:,i)==max(sleeppulse(:,i)),1);
                reblat(i)=(sleeptime(reblatind(i))-1)*1440;
            else
                reblatind(i)=NaN;
                reblat(i)=NaN;
            end
        else
        reblatind(i)=1;
        reblat(i)=1;
%         pulsetime=sleeptime(((depday-1)+(pulse/24))*(sr/30):((depday-1)+(pulse/24)+(recobinpulse/24))*(sr/30)-1);
%         for use if you want to know the exact time and day replace
%         sleeptime below with pulsetime
        end
        
        %calculating TST during second heat pulse
        if strcmpi(PULSE2,'Y') == 1
            nightsleeppulse(i)=sum(sleepdata((nightpulseday-0.5)*sr:nightpulseday*sr-1,i));
        end

        sleepprobpredep=sleeppredep./sr*100;
        daysleepprobpredep=daysleeppredep./sr*100;
        nightsleepprobpredep= nightsleeppredep./sr*100;
        sleepprobdep=sleepdep./sr*100;
        daysleepprobdep=daysleepdep./sr*100;
        nightsleepprobdep=nightsleepdep./sr*100;
        sleepprobreco=sleepreco./sr*100;
        daysleepprobreco=daysleepreco./sr*100;
        nightsleepprobreco=nightsleepreco./sr*100;
        sleepprobrecobin=sleeprecobin./sr*100;
        sleepprobreboundbin=sleepreboundbin./sr*100;
        if strcmpi(PULSE2,'Y') == 1;
        nightsleepprobpulse=nightsleeppulse./sr*100;
        end
   end

%calculating sleep latency for each night
    latindN=ones(End,animalnos);
    latencyN=latindN;
    latindD=latindN;
    latencyD=latindN;
    for i=1:animalnos
        for j=1:End
            if isempty(find(sleepdata(j*sr-(sr/2):j*sr,i),1))==1
                latindN(j,i)=sr/2;
            else
            latindN(j,i)=find(sleepdata(j*sr-(sr/2):j*sr,i),1); %find the index of the first sleep epoch after lights off
            end
        end
    end
    latencyN=latindN.*sam; %converts latency to minutes based on sampling rate
%calculating sleep latency for each day
    for i=1:animalnos
        for j=1:End
            if isempty(find(sleepdata((j-1)*sr+1:j*sr-(sr/2),i),1))==1
                latindD(j,i)=sr/2;
            else
            latindD(j,i)=find(sleepdata((j-1)*sr+1:j*sr-(sr/2),i),1); %find the index of the first sleep epoch after lights off
            end
        end
    end
    latencyD=latindD.*sam; %converts latency to minutes based on sampling rate

%calculating nos and length of all wakefulness and sleep bouts by day
sleepbouts=cell(End,animalnos);
wakebouts=cell(End,animalnos);
sleepboutnos=zeros(End,animalnos);
sleepboutavg=zeros(End,animalnos);
wakeboutnos=zeros(End,animalnos);
wakeboutavg=zeros(End,animalnos);
for i=1:animalnos
    for j=1:End
        tempwind=find(wtsind{i}>=(j-1)*sr & wtsind{i}<=j*sr);
        tempsind=find(stwind{i}>=(j-1)*sr & stwind{i}<=j*sr);
        if numel(tempwind)>numel(tempsind)
        sleepbouts{j,i} = stwind{i}(tempsind)-wtsind{i}(tempwind(1:end-1));
        wakebouts{j,i} = wtsind{i}(tempwind(2:end))-stwind{i}(tempsind);
        elseif numel(tempwind)<numel(tempsind)
        sleepbouts{j,i} = stwind{i}(tempsind(2:end))-wtsind{i}(tempwind);
        wakebouts{j,i} = wtsind{i}(tempwind)-stwind{i}(tempsind(1:end-1));
        else
            if isempty(tempsind)==0
                if tempsind(end)>=tempwind(end)
                sleepbouts{j,i} = stwind{i}(tempsind)-wtsind{i}(tempwind);
                wakebouts{j,i} = wtsind{i}(tempwind(2:end))-stwind{i}(tempsind(1:end-1));
                else
                sleepbouts{j,i} = stwind{i}(tempsind(2:end))-wtsind{i}(tempwind(1:end-1));
                wakebouts{j,i} = wtsind{i}(tempwind)-stwind{i}(tempsind);
                end
            else
            sleepbouts{j,i} = NaN;
            wakebouts{j,i} = NaN;
            end
        end
%use this snippet of code to test for errors in bout analysis (so far so good)
            if isempty(find(wakebouts{j,i}<0,1))==0 || isempty(find(sleepbouts{j,i}<0,1))==0;
            error('there is an error in the bout analysis please check code')
            end
        sleepboutnos(j,i)=numel(sleepbouts{j,i});
        sleepboutavg(j,i)=nanmean(sleepbouts{j,i}).*sam;
        wakeboutnos(j,i)=numel(wakebouts{j,i});
        wakeboutavg(j,i)=nanmean(wakebouts{j,i}).*sam;
    end
end

%Generating group averages for all parameters after removing flies based on
%deprivation threshold
for i=group
    activelineavg(:,i)=nanmean(active(:,groupind(i):groupind(i+1)-1),2);
    sleepproblineavg(:,i)=nanmean(sleepprob(:,groupind(i):groupind(i+1)-1),2);
end

for i=group;
sleepboutlinenos(:,i)=nanmean(sleepboutnos(:,groupind(i):groupind(i+1)-1),2);
sleepboutlineavg(:,i)=nanmean(sleepboutavg(:,groupind(i):groupind(i+1)-1),2);
wakeboutlinenos(:,i)=nanmean(wakeboutnos(:,groupind(i):groupind(i+1)-1),2);
wakeboutlineavg(:,i)=nanmean(wakeboutavg(:,groupind(i):groupind(i+1)-1),2);
end
%% Plotting Sleep Data

%plot sleep propensity in 30min bins
daysLDvec=repelem(1:daysLD,4);
daylightx=[0,0,0.5,0.5]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfillx=repmat(daylightx,1,daysLD);
dayfillx=daysLDvec + dayfillx;
daylighty=[0,1,1,0]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfilly=repmat(daylighty,1,daysLD);
depfillx=[Depstart,Depstart,Depend,Depend];
depfilly=[0,1,1,0];
    if strcmpi(PULSE2,'Y') == 1;
        pulse2fillx=[nightpulsestart,nightpulsestart,nightpulseend,nightpulseend];
        pulse2filly=[0,1,1,0];
    end

% Individual Activity and Binned Sleep Traces
for i=1:animalnos;
    if groupsind(i)==0
        subplot(2,1,1)
        Ylim=max(active(:,i));
        fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
        hold on
        fill(depfillx,depfilly*Ylim,'r','FaceAlpha',0.5)
            if strcmpi(PULSE2,'Y') == 1;
            fill(pulse2fillx,pulse2filly*Ylim,'r','FaceAlpha',0.5)    
            end
        plot(time,active(:,i),'k','LineWidth',2);
        ylabel('Activity (cnts)')
        if Ylim > 1
            ylim([0 Ylim])
        else
            ylim([0 1])
        end
        title(strcat('Activity and Sleep Profiles ',textfilenames(i)));
        hold off
        subplot(2,1,2)
        fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
        hold on
        fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
            if strcmpi(PULSE2,'Y') == 1;
            fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
            end
        plot(sleeptime,sleepprob(:,i),'k','LineWidth',2);
        xlabel('Time (days)')
        ylabel('Sleep Probability (%)')
        hold off
        print(gcf,strcat(textfilenames{i},' Locomotor and Sleep Trace','.pdf'),'-dpdf');
    end
end

% Line Averaged Activity and Binned Sleep Traces
for i=group
    subplot(2,1,1)
    Ylim=max(activelineavg(:,i));
    fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
    hold on
    fill(depfillx,depfilly*Ylim,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1;
        fill(pulse2fillx,pulse2filly*Ylim,'r','FaceAlpha',0.5)    
        end
    plot(time,activelineavg(:,i),'k','LineWidth',2);
    ylabel('Activity (cnts)')
    if Ylim > 1
        ylim([0 Ylim])
    else
        ylim([0 1])
    end
    title(strcat(groupnames{i},' Activity and Sleep Profiles'));
    hold off
    subplot(2,1,2)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1;
        fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
        end
    plot(sleeptime,sleepproblineavg(:,i),'k','LineWidth',2);
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
    print(gcf,strcat('Line Avg ',groupnames{i},' Locomotor and Sleep Trace','.pdf'),'-dpdf');
end

% if there are less than eight lines this will print them all on a single
% axis for visual comparison
if groupnumbers<=8
% figure    
  subplot(2,1,1)
    Ylim=max(max(activelineavg));
    fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
    hold on
    fill(depfillx,depfilly*Ylim,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1;
        fill(pulse2fillx,pulse2filly*Ylim,'r','FaceAlpha',0.5)    
        end
    h1 = plot(time,activelineavg,'LineWidth',1);
    ylabel('Activity (cnts)')
    if Ylim > 1
        ylim([0 Ylim])
    else
        ylim([0 1])
    end
    legend(h1,groupnames,'Location','northwest')
    title(strcat(foldername,' Activity and Sleep Profiles '));
    hold off
    subplot(2,1,2)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1;
        fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
        end
    plot(sleeptime,sleepproblineavg,'LineWidth',1);
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
    savefig(gcf,strcat(foldername,' Locomotor and Sleep Trace Comparisons by line','.fig'));
    print(gcf,strcat(foldername,' Locomotor and Sleep Trace Comparisons by line','.pdf'),'-dpdf');
end

save('SleepDep_variables.mat', '-mat');
%% Extraneous Figure Plotting
if groupnumbers>10
    boxp='compact';
else
    boxp='traditional';
end

%Boxplots of LD and DD data
if strcmp(DD,'Y') == 1;
        positionLD=0.8:1:groupnumbers-0.2;
        positionDD=1.2:1:groupnumbers+0.2;
    %Total Sleep Time
figure
    boxplot(sleepLD,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','y');
    hold on
    boxplot(sleepDD,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'L:D Total Daily Sleep Time by line'))
    ylim([0 max([max(sleepLD) max(sleepDD)])+1])
        box_vars = findall(gca,'Tag','Box');
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    print(strcat(foldername,' Daily TST by line','.pdf'),'-dpdf')

    %Sleep Latency
    boxplot(latencyN(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','y');
    hold on
    boxplot(latencyN(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Sleep Latency by line'))
    ylim([0 max([max(latencyN(LDday,:)) max(latencyN(DDday,:))])+1])
        box_vars = findall(gca,'Tag','Box');
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    print(strcat(foldername,' Sleep Latency by line','.pdf'),'-dpdf')
    
    % Sleep Bout Count
    boxplot(wakeboutnos(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','y');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(wakeboutnos(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Nos (cnts)')
    title(strcat(foldername,'Sleep Bout Nos by line'))
    ylim([0 max([max(sleepboutnos(baseday,:)) max(sleepboutnos(depday,:)) max(sleepboutnos(recoday,:))])+ max([max(sleepboutnos(baseday,:)) max(sleepboutnos(depday,:)) max(sleepboutnos(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');        
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    print(strcat(foldername,' Nos of Sleep Bouts by line','.pdf'),'-dpdf')
    
    % Wake Bout Length
    boxplot(wakeboutavg(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','y');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(wakeboutavg(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Wake Bout Length (min)')
    title(strcat(foldername,'Wake Bout Length by line'))
    ylim([0 max([max(wakeboutavg(baseday,:)) max(wakeboutavg(depday,:)) max(wakeboutavg(recoday,:))])+ max([max(wakeboutavg(baseday,:)) max(wakeboutavg(depday,:)) max(wakeboutavg(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
                hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    print(strcat(foldername,' Wake Bout Length by line','.pdf'),'-dpdf') 
    
    if groupnumbers>10 && strcmp(DD,'Y') == 1;
    % Plotting wakefulness bout nos versus bout length
    gscatter(wakeboutlineavg(LDday,:),wakeboutlinenos(LDday,:),grouping,'y','o')
    hold on
    gscatter(wakeboutlineavg(DDday,:),wakeboutlinenos(DDday,:),grouping,'k','x')
    xlabel('Wake Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    title(strcat(foldername,'Wake Bout Length vs Number by line'))
    print(strcat(foldername,' Wake Bout Length Vs Nos by line','.pdf'),'-dpdf')
    
    gscatter(sleepboutlineavg(LDday,:),wakeboutlinenos(LDday,:),grouping,'y','o')
    hold on
    gscatter(sleepboutlineavg(DDday,:),wakeboutlinenos(DDday,:),grouping,'k','x')
    xlabel('Sleep Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    title(strcat(foldername,'Sleep Bout Length vs Number by line'))
    print(strcat(foldername,' Sleep Bout Length Vs Nos by line','.pdf'),'-dpdf')
    end
end

% Boxplots for Sleep Deprivation
if strcmp(DEP,'Y') == 1;
        positionpredep=0.8:1:groupnumbers-0.2;
        positiondep=1:1:groupnumbers;
        positionreco=1.2:1:groupnumbers+0.2;
    %Daily TST
    figure
    boxplot(sleeppredep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(sleepdep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    set(gca,'XTickLabel',{' '})  % Erase xlabels   
    boxplot(sleepreco,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels   
    hold off     
% set(gca, 'XTickLabel',groupnames, 'XTick',1:numel(groupnames))
% set(gca,'XTickLabelRotation',45)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Daily TST'))
    ylim([0 max([max(sleeppredep) max(sleepdep) max(sleepreco)])*1.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    print(strcat(foldername,' Daily TST by line','.pdf'),'-dpdf')
    %Daytime TST
%     figure
    boxplot(daysleeppredep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(daysleepdep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(daysleepreco,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Daytime TST'))
    ylim([0 max([max(daysleeppredep) max(daysleepdep) max(daysleepreco)])+ max([max(daysleeppredep) max(daysleepdep) max(daysleepreco)])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    print(strcat(foldername,' Daytime TST by line','.pdf'),'-dpdf')
    %Nighttime TST
%     figure
    boxplot(nightsleeppredep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(nightsleepdep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(nightsleepreco,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Nighttime TST'))
    ylim([0 max([max(nightsleeppredep) max(nightsleepdep) max(nightsleepreco)])+ max([max(nightsleeppredep) max(nightsleepdep) max(nightsleepreco)])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    print(strcat(foldername,' Nighttime TST by line','.pdf'),'-dpdf')

% Sleep Recovery
% figure
boxplot(sleeprecobin,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Recovery Sleep'))
    ylim([0 max(sleeprecobin)*1.1])
    print(strcat(foldername,' Recovery Sleep by line','.pdf'),'-dpdf')
    
% Sleep Rebound
% figure
boxplot(sleepreboundbin,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Rebound Sleep'))
    ylim([min(sleepreboundbin)*1.1 max(sleepreboundbin)*1.1])
    print(strcat(foldername,' Rebound Sleep by line','.pdf'),'-dpdf')
    
% Sleep Latency
%     figure
    boxplot(latencyN(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(latencyN(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(latencyN(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Latency (min)')
    title(strcat(foldername,' Sleep Latency at Night by line'))
    ylim([0 max([max(latencyN(baseday,:)) max(latencyN(depday,:)) max(latencyN(recoday,:))])+ max([max(latencyN(baseday,:)) max(latencyN(depday,:)) max(latencyN(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    print(strcat(foldername,' Sleep Latency by line','.pdf'),'-dpdf')

% Sleep Latency after deprivation
%      figure    
    boxplot(latencyD(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k'); 
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Latency (min)')
    title(strcat(foldername,' Latency to sleep after deprivation by line'))
    ylim([0 max(latencyD(recoday,:))*1.1])
    print(strcat(foldername,' Latency To Sleep After Deprivation by line','.pdf'),'-dpdf')

    
% Sleep Bout Count
%     figure
    boxplot(sleepboutnos(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(sleepboutnos(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(sleepboutnos(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Nos (cnts)')
    title(strcat(foldername,' Sleep Bout Nos by line'))
    ylim([0 max([max(sleepboutnos(baseday,:)) max(sleepboutnos(depday,:)) max(sleepboutnos(recoday,:))])+ max([max(sleepboutnos(baseday,:)) max(sleepboutnos(depday,:)) max(sleepboutnos(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    print(strcat(foldername,' Nos of Sleep Bouts by line','.pdf'),'-dpdf')
    
% Sleep Bout Length
%     figure
    boxplot(sleepboutavg(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(sleepboutavg(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(sleepboutavg(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Length (min)')
    title(strcat(foldername,'Sleep Bout Length by line'))
    ylim([0 max([max(sleepboutavg(baseday,:)) max(sleepboutavg(depday,:)) max(sleepboutavg(recoday,:))])+ max([max(sleepboutavg(baseday,:)) max(sleepboutavg(depday,:)) max(sleepboutavg(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    print(strcat(foldername,' Sleep Bout Length by line','.pdf'),'-dpdf') 

% Wake Bout Count
%     figure
    boxplot(wakeboutnos(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(wakeboutnos(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(wakeboutnos(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Wake Bout Nos (cnts)')
    title(strcat(foldername,' Wake Bout Nos by line'))
    ylim([0 max([max(wakeboutnos(baseday,:)) max(wakeboutnos(depday,:)) max(wakeboutnos(recoday,:))])+ max([max(wakeboutnos(baseday,:)) max(wakeboutnos(depday,:)) max(wakeboutnos(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    print(strcat(foldername,' Nos of Wake Bouts by line','.pdf'),'-dpdf')
    
% Wake Bout Length
%     figure
    boxplot(wakeboutavg(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(wakeboutavg(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(wakeboutavg(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Wake Bout Length (min)')
    title(strcat(foldername,' Wake Bout Length by line'))
    ylim([0 max([max(wakeboutavg(baseday,:)) max(wakeboutavg(depday,:)) max(wakeboutavg(recoday,:))])+ max([max(wakeboutavg(baseday,:)) max(wakeboutavg(depday,:)) max(wakeboutavg(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    print(strcat(foldername,' Wake Bout Length by line','.pdf'),'-dpdf')
    
    % TST during second heat pulse
    if strcmpi(PULSE2,'Y') == 1;
%         figure
boxplot(nightsleeppulse,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Nighttime TST During 2nd Pulse'))
    ylim([min(nightsleeppulse)-abs(min(nightsleeppulse)*0.1) max(nightsleeppulse)*1.1])
    print(strcat(foldername,' TST during 2nd pulse by line','.pdf'),'-dpdf')
end
    

 %%   
    if max(groupnumbers)>10 && strcmp(DD,'Y') == 1;
    % Plotting wakefulness bout nos versus bout length
%     figure
    gscatter(wakeboutlineavg(baseday,:),wakeboutlinenos(baseday,:),groupnumbers,'b','o')
    hold on
    gscatter(wakeboutlineavg(depday,:),wakeboutlinenos(depday,:),groupnumbers,'r','x')
    gscatter(wakeboutlineavg(recoday,:),wakeboutlinenos(recoday,:),groupnumbers,'g','+')
    hold off
    xlabel('Wake Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    title(strcat(foldername,' Wake Bout Length vs Number by line'))
    print(strcat(foldername,' Wake Bout Length Vs Nos by line','.pdf'),'-dpdf')
    
    % Plotting sleep bout nos versus bout length
%         figure
    gscatter(sleepboutlineavg(baseday,:),sleepboutlinenos(baseday,:),groupnumbers,'b','o')
    hold on
    gscatter(sleepboutlineavg(depday,:),sleepboutlinenos(depday,:),groupnumbers,'r','x')
    gscatter(sleepboutlineavg(recoday,:),sleepboutlinenos(recoday,:),groupnumbers,'g','+')
    hold off
    xlabel('Sleep Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    title(strcat(foldername,' Sleep Bout Length vs Number by line'))
    print(strcat(foldername,' Sleep Bout Length Vs Nos by line','.pdf'),'-dpdf')
    end
end
%% Plot sleep probability in LD vs DD for all lines
    if groupnumbers>10 && strcmp(DD,'Y') == 1;
    for i=group;
    sleepprobavg(:,i) = nanmean(sleepprob(groupind(i):groupind(i+1)-1));
    sleepLDavg(i) = nanmean(sleepLD(groupind(i):groupind(i+1)-1));
        if strcmp(DD,'Y') == 1;
        sleepDDavg(i) = nanmean(sleepDD(groupind(i):groupind(i+1)-1));
        end
    end

    if nosperline > 1
        if max(sleepLDavg)>max(sleepDDavg)
        X=0:1:max(sleepDDavg);
        Y=0:1:max(sleepDDavg);
        else
        X=0:1:max(sleepLDavg);
        Y=0:1:max(sleepLDavg); 
        end

%     figure
    scatter(sleepLDavg,sleepDDavg,'b');
    hold on
    plot(X,Y,'r')
    xlabel('Average Total Sleep Time (min) During LD')
    ylabel('Average Total Sleep Time (min) In Constant Darkness')
    title(strcat(foldername,' Total Daily Sleep Time by line'))
    ylim([0 max(sleepDDavg)+1])
    xlim([0 max(sleepLDavg)+1])
    savefig(strcat(foldername,' Daily TST LD vs DD Scatter Plot','.fig'))
    print(strcat(foldername,' Daily TST LD vs DD Scatter Plot','.pdf'),'-dpdf')
    end

    % Plot histograms for TST in LD and DD for screen
%     figure
    subplot(1,2,1)
    histfit(sleepLDavg,10);
    xlabel('Total Sleep Time')
    title('L:D')
    subplot(1,2,2)
    histfit(sleepDDavg,10);
    xlabel('Total Sleep Time')
    title('D:D')
    print(strcat(foldername,' Daily TST Histograms','.pdf'),'-dpdf')
end


if groupnumbers>10 && strcmp(DEP,'Y') == 1;
    % Plot histograms for TST during baseline, Deprivation, and Recovery   
    for i=group;
    sleeppredepavg(:,i) = nanmean(sleeppredep(groupind(i):groupind(i+1)-1));
    sleepdepavg(:,i) = nanmean(sleepdep(groupind(i):groupind(i+1)-1));
    sleeprecoavg(:,i) = nanmean(sleepreco(groupind(i):groupind(i+1)-1));
    end
    
        if sum(nosperline) > 1
        X=0:1:max([max(sleeppredepavg) max(sleepdepavg) max(sleeprecoavg)]);
        Y=0:1:max([max(sleeppredepavg) max(sleepdepavg) max(sleeprecoavg)]);
        Z=0:1:max([max(sleeppredepavg) max(sleepdepavg) max(sleeprecoavg)]);
        end
  figure
    scatter3(sleeppredepavg,sleepdepavg,sleeprecoavg,5,'b','filled');
    view(40,35)
    hold on
    plot3(X,Y,Z,'r')
    hold off
    xlabel('Average Baseline TST(min)')
    ylabel('Average Deprivation TST(min)')
    zlabel('Average Recovery TST(min)')
    title('Total Daily Sleep Time by line')
    xlim([0 max(sleeppredepavg)*1.1])
    ylim([0 max(sleepdepavg)*1.1])
    zlim([0 max(sleeprecoavg)*1.1])
    savefig(strcat(foldername,' Daily TST Baseline vs Deprivation vs recovery Scatter Plot','.fig'))
    print(strcat(foldername,' Daily TST Baseline vs Deprivation vs recovery Scatter Plot','.pdf'),'-dpdf')
    
%     figure
    subplot(3,1,1)
    hist(sleeppredepavg,10);
    xlabel('Total Sleep Time')
    title('Baseline')
    subplot(3,1,2)
    hist(sleepdepavg,10);
    xlabel('Total Sleep Time')
    title('Deprivation')
    subplot(3,1,3)
    hist(sleeprecoavg,10);
    xlabel('Total Sleep Time')
    title('Recovery')
    print(strcat(foldername,' Total Daily Sleep Time Histograms','.pdf'),'-dpdf')
end


close all;
save('SleepDep_variables.mat', '-mat');
end
clear all;
end
