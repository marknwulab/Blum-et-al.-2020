%Run and plot sleep data from Trikinetics locomotor monitors, including
%individual and grouped analysis

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%  to do: 
% -split into sleepdep and sleepLDDD functions

function []=tksleepdep_parfor(varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
%  preallocating for speed
dlen=size(datatrim,1);
slen=dlen/sleepbin;

% Generates sliding window to define lack of activity as sleep
sleepsum=zeros(size(datatrim,1)-sleepdef,animalnos);
sleepsumbeg=ones(sleepdef,animalnos);
for i=1:animalnos
   for j=1:size(datatrim,1)-sleepdef
    sleepsum(j,i)=sum(datatrim(j:(j-1)+sleepdef,i));
   end
end
sleepsum=[sleepsumbeg;sleepsum]; %just padding the last first minutes with no sleep and very low activity

%locate all the sleep epochs and generates sleepdata logical matrix
sleepind=find(~sleepsum); %locates all the sleep epochs
sleepdata=zeros(size(datatrim));
for i=1:sleepdef
sleepdata(sleepind(5:end)+1-i)=1;
end
active=datatrim;
if strcmp(ALL,'Y') == 1
sleepdata(:,deadind)=NaN; %Remove all dead animals from sleep analysis
active(:,deadind)=NaN; %Remove all dead animals from activity analysis
end

%locate all sleep/wake transitions
krn=[1 -1];
transitions=zeros(dlen+1,animalnos);
wtsind=cell(1,animalnos);
stwind=cell(1,animalnos);
parfor k=1:animalnos
    transitions(:,k)=conv(krn,sleepdata(:,k));
    wtsind{1,k}=find(transitions(:,k)==1); %all wake to sleep transitions
    stwind{1,k}=find(transitions(:,k)==-1); %all sleep to wake transitions
end

%% Sleep Analysis
if strcmp(DEP,'Y') == 1;
% generating index to remove all animals without sufficient nighttime sleep deprivation
    nightsleeppredep=zeros(1,animalnos);
    nightsleepdep=zeros(1,animalnos);
    basetrim=(baseday-0.5)*sr+1:(baseday)*sr;
    deptrim=(depday-0.5)*sr:(depday)*sr-1;
    parfor i=1:animalnos;
        nightsleeppredep(i)=sum(sleepdata(basetrim,i));
        nightsleepdep(i)=sum(sleepdata(deptrim,i));
    end
% Remove animals (from exp groups) which do not meet sleep dep threshold      
    if numel(grouptype)~=groupnumbers
                error('please recheck the input for "grouptype"')
    end

    if isempty(grouptype)==0;
        if isnan(numperline)==1;
            groupdepind=ones(1,animalnos);
        elseif exist('grouptype') == 1
            groupdepind=repelem(strcmpi('E',grouptype),nosperline);
        else
            groupdepind=zeros(1,animalnos);
        end
        


    depeffect=100-(nightsleepdep./nightsleeppredep.*100);
    depind=find(depeffect<depthresh & groupdepind==1);
    active(:,depind)=NaN;
    sleepdata(:,depind)=NaN;
        for i=1:length(depind)
        wtsind{1,depind(i)}=[];
        stwind{1,depind(i)}=[];
        end
    end
end
% Calculating the final group sizes after accounting for dead animals and
% those that lack appropriate deprivation
groupsind=isnan(sleepdata(1,:));
groups=ones(1,animalnos).*~groupsind;
temp=zeros(1,animalnos);temp(deadind)=1;deadgroups=temp;
    if isempty(grouptype)==0
    temp=zeros(1,animalnos);temp(depind)=1;depgroups=temp;
    else
    depgroups=ones(1,animalnos);
    end
groupsize=zeros(1,groupnumbers);deadsize=zeros(1,groupnumbers);depsize=zeros(1,groupnumbers);
    for i=group
    groupsize(i)=sum(groups(groupind(i):groupind(i+1)-1));
    deadsize(i)=sum(deadgroups(groupind(i):groupind(i+1)-1));
    depsize(i)=sum(depgroups(groupind(i):groupind(i+1)-1));
    end
  
% finding sleep probability per bin
sleeptime=((1:size(sleepdata,1)/sleepbin)/sleepsr)+1; %generates a timeseries for sleepbinning
sleepprob=zeros(slen,animalnos);
sb=sleepbin;
parfor i=1:animalnos
   sd=sleepdata(:,i)
   for j=1:slen
   sbtrim=(sb*j)-sb+1:sb*j;
   sleepprob(j,i)=sum(sd(sbtrim))/sb*100;
   end
end

%Total Sleep Time (TST) for designated days in LD and DD
if strcmp(DD,'Y') == 1
    LDtrim=(LDday-1)*sr+1:LDday*sr;
    DDtrim=(DDday-1)*sr+1:DDday*sr;
    parfor i=1:animalnos
    sleepLD(i)=sum(sleepdata(LDtrim,i));
    sleepDD(i)=sum(sleepdata(DDtrim,i));
    end
sleepprobLD=sleepLD./sr*100;
sleepprobDD=sleepDD./sr*100;
end

%TST and day/night analysis for baseline, deprivation, recovery, and during
%the pulse
if strcmp(DEP,'Y') == 1
    for i=1:animalnos
        %Day/Night Total Sleep Time (TST) by Day
        for j=1:last-first+1        
        nightsleep(j,i)=sum(sleepdata((j-0.5)*sr+1:(j)*sr,i));
        daysleep(j,i)=sum(sleepdata((j-1)*sr+1:(j-0.5)*sr,i));
        end
        %baseline day
        sleeppredep(i)=sum(sleepdata((baseday-1)*sr+1:(baseday)*sr,i));
        daysleeppredep(i)=sum(sleepdata((baseday-1)*sr+1:(baseday-0.5)*sr,i));
        nightsleeppredep(i)=sum(sleepdata((baseday-0.5)*sr+1:(baseday)*sr,i));
        %deprivation day
        sleepdep(i)=sum(sleepdata((depday-1)*sr:(depday)*sr-1,i));
        daysleepdep(i)=sum(sleepdata((depday-1)*sr:(depday-0.5)*sr,i));
        nightsleepdep(i)=sum(sleepdata((depday-0.5)*sr:(depday)*sr,i));
        activenightwakemeandep(i)=median(nonzeros(active((depday-0.4)*sr:(depday-0.1)*sr,i)));
        %recovery day
        sleepreco(i)=sum(sleepdata((recoday-1)*sr:recoday*sr-1,i));
        daysleepreco(i)=sum(sleepdata((recoday-1)*sr:(recoday-0.5)*sr,i));
        activedaywakemeanreco(i)=median(nonzeros(active(floor((recoday-0.9)*sr):floor((recoday-0.6)*sr),i)));
        nightsleepreco(i)=sum(sleepdata((recoday-0.5)*sr:recoday*sr,i));
        
        %Sleep recovery epoch (defined by recobinpulse)
        if strcmpi(PULSE,'Y') == 1
            %Baseline sleep during recovery timeframe
            pulsesleeppredep(i)=sum(sleepdata(((baseday-1)+(pulse/24))*sr+1:((baseday-1)+(pulse/24)+(recobinpulse/24))*sr,i));
            %Sleep recovery
            sleeprecobin(i)=sum(sleepdata(((depday-1)+(pulse/24))*sr+1:((depday-1)+(pulse/24)+(recobinpulse/24))*sr,i));
            %Sleep Rebound      
            sleepreboundbin(i)=sleeprecobin(i)-pulsesleeppredep(i);
            %Individual Percent Sleep Recovered
            percsleeprecovbin(i)=(sleeprecobin(i)-pulsesleeppredep(i))/(nightsleeppredep(i)-nightsleepdep(i));
        else
            pulsesleeppredep(i)=sum(sleepdata((baseday)*sr+1:((baseday)+(recobin/24))*sr,i));
            sleeprecobin(i)=sum(sleepdata((depday)*sr+1:((depday)+(recobin/24))*sr,i));
            sleepreboundbin(i)=sleeprecobin(i)-pulsesleeppredep(i);
            percsleeprecovbin(i)=(sleeprecobin(i)-pulsesleeppredep(i))/(nightsleeppredep(i)-nightsleepdep(i))*100;
        end
   
%Calculating cumulative sleep lost due to deprivation as a percentage
deplen=1.5*sr/sleepbin;
deptime=((1:1.5*sr/sleepbin)/sleepsr)+Depstart; %generates a timeseries for sleepbinning
sleeplost=zeros(deplen,animalnos);
binsleep=sleepprob/100*sleepbin;
if strcmpi(PULSE,'N') == 1   
for i=1:animalnos
      ds=Depstart;
      sd=binsleep(:,i);
      for j=1:deplen
         sleeplost(j,i)=sd((ds-1)*sleepsr+j)-sd((ds-2)*sleepsr+j);
      end
end
for i=1:animalnos
       sd=sleeplost(:,i);
       for j=1:deplen
           cumsleeplostperc(j,i)=sum(sd(1:j))/nightsleeppredep(i)*100; %************************************************
       end
end
end
if strcmpi(PULSE,'N') == 1
sleeplost(:,depind)=NaN;    
cumsleeplostperc(:,depind)=NaN; %scrubbing data from animals not meeting dep threshold.
else cumsleeplostperc=zeros(deplen,animalnos);
end

%calculating latency to sleep after the end of sleep deprivation or heat activation
        if strcmpi(PULSE,'Y') == 1 
            sleeppulse(:,i)=sleepdata(((Depend-1+(pulse/24))*sr+1):ceil((Depend-1)+(recobinpulse/24))*sr,i);
        else
            sleeppulse(:,i)=sleepdata(depday*sr:((depday)+(recobin/24))*sr,i);    
        end    
        
        if sum(sleeppulse(:,i))>=1
                reblatind(i)=find(sleeppulse(:,i)==1,1);
                reblat(i)=(time(reblatind(i))-1)*1440;
            else
                reblatind(i)=NaN;
                reblat(i)=NaN;
        end
                
%         %calculating time to maximal sleep after activation/deprivation (or
%         %alternatively consider plotting slope of rebound activation?
%         should probably use 
%         if strcmpi(PULSE,'Y') == 1 
%         sleeppulse(:,i)=sleepprob(((depday)+(pulse/24))*(sr/30):((depday)+(pulse/24)+(recobinpulse/24))*(sr/30),i);
%         else
%         sleeppulse(:,i)=sleepprob(((depday))*(sr/30):((depday)+(recobin/24))*(sr/30),i);    
%         end    
%         
%         if sum(sleeppulse(:,i))>=1
%                 reblatind(i)=find(sleeppulse(:,i)==max(sleeppulse(:,i)),1);
%                 reblat(i)=(sleeptime(reblatind(i))-1)*1440;
%             else
%                 reblatind(i)=NaN;
%                 reblat(i)=NaN;
%         end
        
        %calculating TST during second heat pulse
        if strcmpi(PULSE2,'Y') == 1
            nightsleeppulse(i)=sum(sleepdata((nightpulseday-0.5)*sr:nightpulseday*sr-1,i));
        end
end

%calculating sleep latency for each night
    latindN=NaN(End,animalnos); %Preallocate
    latencyN=latindN; %Preallocate
    latindD=latindN; %Preallocate
    latencyD=latindN; %Preallocate
    
    for i=1:animalnos
        for j=1:End
            if isempty(find(sleepdata(j*sr-(sr/2):j*sr,i),1))==1
                latindN(j,i)=sr/2;
            elseif isnan(sum(sleepdata(j*sr-(sr/2):j*sr,i),1))==1
                latindN(j,i)=NaN;
            else
            latindN(j,i)=find(sleepdata(j*sr-(sr/2):j*sr,i),1); %find the index of the first sleep epoch after lights off
            end
        end
    end
    latencyN=latindN.*sam; %converts latency to minutes based on sampling rate
%calculating sleep latency for each day
    for i=1:animalnos
        for j=1:End
            if isempty(find(sleepdata((j-1)*sr+1:j*sr-(sr/2),i),1))==1
                latindD(j,i)=sr/2;
            elseif isnan(sum(sleepdata(j*sr-(sr/2):j*sr,i),1))==1
                latindD(j,i)=NaN;
            else
            latindD(j,i)=find(sleepdata((j-1)*sr+1:j*sr-(sr/2),i),1); %find the index of the first sleep epoch after lights off
            end
        end
    end
    latencyD=latindD.*sam; %converts latency to minutes based on sampling rate

%calculating nos and length of all wakefulness and sleep bouts by day
sleepbouts=cell(End,animalnos);
wakebouts=cell(End,animalnos);
sleepboutnos=NaN(End,animalnos);
sleepboutavg=NaN(End,animalnos);
wakeboutnos=NaN(End,animalnos);
wakeboutavg=NaN(End,animalnos);
for i=1:animalnos
    for j=1:End
        tempwind=find(wtsind{i}>=(j-1)*sr & wtsind{i}<=j*sr);
        tempsind=find(stwind{i}>=(j-1)*sr & stwind{i}<=j*sr);
        if numel(tempwind)>numel(tempsind)
        sleepbouts{j,i} = stwind{i}(tempsind)-wtsind{i}(tempwind(1:end-1)); % need to recode this to not ignore the bout at the transition
        wakebouts{j,i} = wtsind{i}(tempwind(2:end))-stwind{i}(tempsind);% need to recode this to not ignore the bout at the transition
        elseif numel(tempwind)<numel(tempsind)
        sleepbouts{j,i} = stwind{i}(tempsind(2:end))-wtsind{i}(tempwind);% need to recode this to not ignore the bout at the transition
        wakebouts{j,i} = wtsind{i}(tempwind)-stwind{i}(tempsind(1:end-1));% need to recode this to not ignore the bout at the transition
        else
            if isempty(tempwind)==0
                if tempsind(end)>=tempwind(end)
                sleepbouts{j,i} = stwind{i}(tempsind)-wtsind{i}(tempwind);
                wakebouts{j,i} = wtsind{i}(tempwind(2:end))-stwind{i}(tempsind(1:end-1));
                else
                sleepbouts{j,i} = stwind{i}(tempsind(2:end))-wtsind{i}(tempwind(1:end-1));
                wakebouts{j,i} = wtsind{i}(tempwind)-stwind{i}(tempsind);
                end
            else
            sleepbouts{j,i} = NaN;
            wakebouts{j,i} = NaN;
            end
        end
%use this snippet of code to test for errors in bout analysis (so far so good)
            if isempty(find(wakebouts{j,i}<0,1))==0 || isempty(find(sleepbouts{j,i}<0,1))==0;
            error('there is an error in the bout analysis please check code')
            end
        sleepboutnos(j,i)=numel(sleepbouts{j,i});
        sleepboutavg(j,i)=nanmean(sleepbouts{j,i}).*sam;
        wakeboutnos(j,i)=numel(wakebouts{j,i});
        wakeboutavg(j,i)=nanmean(wakebouts{j,i}).*sam;
    end
end
if strcmp(ALL,'Y') == 1
for i=1:End
sleepboutnos(i,deadind)=NaN;
sleepboutavg(i,deadind)=NaN;
wakeboutnos(i,deadind)=NaN;
wakeboutavg(i,deadind)=NaN;
end
end
if strcmpi(DEP,'Y') == 1 && exist('depind','var')==1
    for i=1:End
    sleepboutnos(i,depind)=NaN;
    sleepboutavg(i,depind)=NaN;
    wakeboutnos(i,depind)=NaN;
    wakeboutavg(i,depind)=NaN;
    end
end
    
% Calculating Sleep bout length and nos during for day/night comparisons
% (N.B. that this can be used to look at fragmentation mid phase as in
% Tabuchi et al. Cell 2018

%This is for baseline sleep fragmentation 
for i=1:animalnos
        tempwindday=find(wtsind{i}>=((baseday-1)*sr)+(midds*60/sam) & wtsind{i}<=((baseday-1)*sr)+(midde*60/sam));
        tempwindnight=find(wtsind{i}>=((baseday-1)*sr)+(midns*60/sam) & wtsind{i}<=((baseday-1)*sr)+(midne*60/sam));
        tempsindday=find(stwind{i}>=((baseday-1)*sr)+(midds*60/sam) & stwind{i}<=((baseday-1)*sr)+(midde*60/sam));
        tempsindnight=find(stwind{i}>=((baseday-1)*sr)+(midns*60/sam) & stwind{i}<=((baseday-1)*sr)+(midne*60/sam));
        tempwday=wtsind{i}(tempwindday);
        tempwnight=wtsind{i}(tempwindnight);
        tempsday=stwind{i}(tempsindday);
        tempsnight=stwind{i}(tempsindnight);
        %day
        if isempty(tempsindday)==1 && isempty(tempwindday)==1
            sleepboutsday{i}=sum(sleepdata((midds*60/sam)+1:(midde*60/sam)-1,i));
        elseif numel(tempsindday)==1 && numel(tempwindday)==1
            if tempsday<tempwday
            sleepboutsday{i}= [tempsday-((midds*60/sam)+1);((midde*60/sam)-1)-tempwday]; %take stw-start & end-wts
            else
            sleepboutsday{i}=tempsday-tempwday; %stw-wts
            end
        elseif isempty(tempwindday)==1 && isempty(tempsindday)==0
            sleepboutsday{i}=tempsday-(midde*60/sam); %stw-start
        elseif isempty(tempwindday)==0 && isempty(tempsindday)==1        
            sleepboutsday{i}=(midde*60/sam)-tempwday; %end-wts
        elseif isempty(tempwindday)==0 && isempty(tempsindday)==0
            if numel(tempwindday)>numel(tempsindday)
            sleepboutsday{i} = [tempsday;(midde*60/sam)]-tempwday;
            elseif numel(tempwindday)<numel(tempsindday)
            sleepboutsday{i} = tempsday-[(midds*60/sam);tempwday];
            elseif numel(tempwindday)==numel(tempsindday)
                if tempwday(end)<tempsday(end)
                sleepboutsday{i} = tempsday-tempwday;
                else
                sleepboutsday{i} = [tempsday;(midde*60/sam)]-[(midds*60/sam);tempwday];    
                end
            end
        end
        %night
        if isempty(tempsindnight)==1 && isempty(tempwindnight)==1
            sleepboutsnight{i}=sum(sleepdata((midns*60/sam)+1:(midne*60/sam-1),i));
        elseif numel(tempwindnight)==1 && numel(tempsindnight)==1
            if tempsnight<tempwnight
            sleepboutsnight{i}= [tempsnight-(midns*60/sam);(midne*60/sam-1)-tempwnight]; %take stw-start & end-wts
            else
            sleepboutsnight{i}=tempsnight-tempwnight; %stw-wts
            end
        elseif isempty(tempwindnight)==1 && isempty(tempsindnight)==0
            sleepboutsnight{i}=tempsnight-((midns*60/sam)+1); %stw-start
        elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==1        
            sleepboutsnight{i}=((midne*60/sam)-1)-tempwnight; %end-wts
        elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==0
            if numel(tempwindnight)>numel(tempsindnight)
            sleepboutsnight{i} = [tempsnight;(midne*60/sam)-1]-tempwnight;
            elseif numel(tempwindnight)<numel(tempsindnight)
            sleepboutsnight{i} = tempsnight-[(midns*60/sam)+1;tempwnight];
            elseif numel(tempwindnight)==numel(tempsindnight)
                if tempwnight(end)<tempsnight(end)
                sleepboutsnight{i} = tempsnight-tempwnight;
                else
                sleepboutsnight{i} = [tempsnight;(midne*60/sam)-1]-[(midns*60/sam)+1;tempwnight];    
                end
            end
        end
%use this snippet of code to test for errors in bout analysis (so far so good)
if isempty(find(wakebouts{i}<0,1))==0 || isempty(find(sleepbouts{i}<0,1))==0
error('there is an error in the bout analysis please check code')
end
    sleepboutnosday(i)=numel(sleepboutsday{i});
        if isempty(sleepboutnosday(i)) || isnan(sleepboutnosday(i))
        sleepboutnosday(i) = 0;
        elseif sum(sleepboutsday{i})==0
        sleepboutnosday(i) = 0;
        end
    sleepboutavgday(i)=nanmean(sleepboutsday{i}).*sam;

    sleepboutnosnight(i)=numel(sleepboutsnight{i});
        if isempty(sleepboutnosnight(i)) || isnan(sleepboutnosnight(i))
        sleepboutnosnight(i) = 0;
        elseif sum(sleepboutsnight{i})==0
        sleepboutnosnight(i) = 0;
        end
    sleepboutavgnight(i)=nanmean(sleepboutsnight{i}).*sam;

    sleepboutnosratio(i)=sleepboutnosday(i)/sleepboutnosnight(i); %bout nos
    sleepboutavgratio(i)=sleepboutavgday(i)/sleepboutavgnight(i); %bout length
end

%This is for activation and rebound
if strcmpi(DEP,'Y') == 1
clear tempwday tempwnight tempsday tempsnight k;
    for i=1:animalnos
            tempwindday=find(wtsind{i}>=(midrs*60/sam) & wtsind{i}<=(midre*60/sam));
            tempwindnight=find(wtsind{i}>=(midas*60/sam) & wtsind{i}<=(midae*60/sam));
            tempsindday=find(stwind{i}>=(midrs*60/sam) & stwind{i}<=(midre*60/sam));
            tempsindnight=find(stwind{i}>=(midas*60/sam) & stwind{i}<=(midae*60/sam));
            tempwday=wtsind{i}(tempwindday);
            tempwnight=wtsind{i}(tempwindnight);
            tempsday=stwind{i}(tempsindday);
            tempsnight=stwind{i}(tempsindnight);
            %Rebound
            if isempty(tempsindday)==1 && isempty(tempwindday)==1
                sleepboutsrebound{1,i}=sum(sleepdata((midrs*60/sam):(midre*60/sam-1),i));
                sleepboutsrebound{2,i}=1;
            elseif numel(tempwindday)==1 && numel(tempsindday)==1
                if tempsday<tempwday
                sleepboutsrebound{1,i}= [tempsday-(midrs*60/sam);(midre*60/sam)-tempwday]; %take stw-start & end-wts
                sleepboutsrebound{2,i}=2;
                else
                sleepboutsrebound{1,i}=tempsday-tempwday; %stw-wts
                sleepboutsrebound{2,i}=3;
                end
            elseif isempty(tempwindday)==1 && isempty(tempsindday)==0
                sleepboutsrebound{1,i}=tempsday-(midrs*60/sam); %stw-start
                sleepboutsrebound{2,i}=4;
            elseif isempty(tempwindday)==0 && isempty(tempsindday)==1        
                sleepboutsrebound{1,i}=(midre*60/sam)-tempwday; %end-wts
                sleepboutsrebound{2,i}=5;
            elseif isempty(tempwindday)==0 && isempty(tempsindday)==0
                if numel(tempwindday)>numel(tempsindday)
                sleepboutsrebound{1,i} = [tempsday;(midre*60/sam)]-tempwday;
                sleepboutsrebound{2,i}=6;
                elseif numel(tempwindday)<numel(tempsindday)
                sleepboutsrebound{1,i} = tempsday-[(midrs*60/sam);tempwday];
                sleepboutsrebound{2,i}=7;
                elseif numel(tempwindday)==numel(tempsindday)
                    if tempwday(end)<tempsday(end)
                    sleepboutsrebound{1,i} = tempsday-tempwday;
                    sleepboutsrebound{2,i}=8;
                    else
                    sleepboutsrebound{1,i} = [tempsday;(midre*60/sam)]-[(midrs*60/sam);tempwday];    
                    sleepboutsrebound{2,i}=9;
                    end
                end
            end
            %Activation
            if isempty(tempsindnight)==1 && isempty(tempwindnight)==1
                sleepboutsactivation{1,i}=sum(sleepdata((midas*60/sam):(midae*60/sam-1),i));
                sleepboutsactivation{2,i}=1;
            elseif numel(tempwindnight)==1 && numel(tempsindnight)==1
                if tempsnight<tempwnight
                sleepboutsactivation{1,i}= [tempsnight-(midas*60/sam);(midae*60/sam)-tempwnight]; %take stw-start & end-wts
                sleepboutsactivation{2,i}=2;
                else
                sleepboutsactivation{1,i}=tempsnight-tempwnight; %stw-wts
                sleepboutsactivation{2,i}=3;
                end
            elseif isempty(tempwindnight)==1 && isempty(tempsindnight)==0
                sleepboutsactivation{1,i}=tempsnight-(midas*60/sam); %stw-start
                sleepboutsactivation{2,i}=4;
            elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==1        
                sleepboutsactivation{1,i}=(midae*60/sam)-tempwnight; %end-wts
                sleepboutsactivation{2,i}=5;
            elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==0
                if numel(tempwindnight)>numel(tempsindnight)
                sleepboutsactivation{1,i} = [tempsnight;(midae*60/sam)]-tempwnight;
                sleepboutsactivation{2,i}=6;
                elseif numel(tempwindnight)<numel(tempsindnight)
                sleepboutsactivation{1,i} = tempsnight-[(midas*60/sam);tempwnight];
                sleepboutsactivation{2,i}=7;
                elseif numel(tempwindnight)==numel(tempsindnight)
                    if tempwnight(end)<tempsnight(end)
                    sleepboutsactivation{1,i} = tempsnight-tempwnight;
                    sleepboutsactivation{2,i}=8;
                    else
                    sleepboutsactivation{1,i} = [tempsnight;(midae*60/sam)]-[(midas*60/sam);tempwnight];
                    sleepboutsactivation{2,i}=9;
                    end 
                end
            end
    %use this snippet of code to test for errors in bout analysis (so far so good)
        if isempty(find(wakebouts{i}<0,1))==0 || isempty(find(sleepbouts{i}<0,1))==0
        error('there is an error in the bout analysis please check code')
        end

        sleepboutnosrebound(i)=numel(sleepboutsrebound{1,i});
                if isempty(sleepboutnosrebound(i)) || isnan(sleepboutnosrebound(i))
                    sleepboutnosrebound(i) = 0;
                elseif sum(sleepboutsrebound{1,i})==0
                    sleepboutnosrebound(i) = 0;
                end
        sleepboutavgrebound(i)=nanmean(sleepboutsrebound{1,i}).*sam;

        sleepboutnosactivation(i)=numel(sleepboutsactivation{1,i});
                if isempty(sleepboutnosactivation(i)) || isnan(sleepboutnosactivation(i))
                    sleepboutnosnight(i) = 0;
                elseif sum(sleepboutsactivation{1,i})==0
                    sleepboutnosactivation(i) = 0;
                end
        sleepboutavgactivation(i)=nanmean(sleepboutsactivation{1,i}).*sam;

    end
end

if strcmp(ALL,'Y') == 1
sleepboutnosday(deadind)=NaN;
sleepboutnosnight(deadind)=NaN;
sleepboutavgday(deadind)=NaN;
sleepboutavgnight(deadind)=NaN;
sleepboutnosratio(deadind)=NaN;
sleepboutavgratio(deadind)=NaN;
end
if strcmpi(DEP,'Y') == 1
    if strcmp(ALL,'Y') == 1
    sleepboutnosrebound(deadind)=NaN;
    sleepboutavgrebound(deadind)=NaN;
    sleepboutnosactivation(deadind)=NaN;
    sleepboutavgactivation(deadind)=NaN;
    end
    if exist('depind','var')==1
    sleepboutnosday(depind)=NaN;   
    sleepboutnosnight(depind)=NaN;
    sleepboutnosratio(depind)=NaN;
    sleepboutnosrebound(depind)=NaN;
    sleepboutnosactivation(depind)=NaN;
    end
    
    
end
%Generating group averages for all parameters after removing flies based on
%deprivation threshold
for i=group
    activelineavg(:,i)=nanmean(active(:,groupind(i):groupind(i+1)-1),2);
    sleepproblineavg(:,i)=nanmean(sleepprob(:,groupind(i):groupind(i+1)-1),2);
    cumsleeplostperclineavg(:,i)=nanmean(cumsleeplostperc(:,groupind(i):groupind(i+1)-1),2);
    sleeppredeplineavg(i)=nanmean(sleeppredep(:,groupind(i):groupind(i+1)-1),2);
    daysleeppredeplineavg(i)=nanmean(daysleeppredep(:,groupind(i):groupind(i+1)-1),2);
    nightsleeppredeplineavg(i)=nanmean(nightsleeppredep(:,groupind(i):groupind(i+1)-1),2);
    sleepdeplineavg(i)=nanmean(sleepdep(:,groupind(i):groupind(i+1)-1),2);
    daysleepdeplineavg(i)=nanmean(daysleepdep(:,groupind(i):groupind(i+1)-1),2);
    nightsleepdeplineavg(i)=nanmean(nightsleepdep(:,groupind(i):groupind(i+1)-1),2);
    sleeprecolineavg(i)=nanmean(sleepreco(:,groupind(i):groupind(i+1)-1),2);
    daysleeprecolineavg(i)=nanmean(daysleepreco(:,groupind(i):groupind(i+1)-1),2);
    nightsleeprecolineavg(i)=nanmean(nightsleepreco(:,groupind(i):groupind(i+1)-1),2);
    pulsesleeppredeplineavg(i)=nanmean(pulsesleeppredep(:,groupind(i):groupind(i+1)-1),2);
    sleeprecobinlineavg(i)=nanmean(sleeprecobin(:,groupind(i):groupind(i+1)-1),2);
    sleepreboundbinlineavg(i)=nanmean(sleepreboundbin(:,groupind(i):groupind(i+1)-1),2);
    percsleeprecovbinlineavg(i)=nanmean(percsleeprecovbin(:,groupind(i):groupind(i+1)-1),2);
    activenightwakemeandeplineavg(i)=nanmean(activenightwakemeandep(:,groupind(i):groupind(i+1)-1),2);
    activedaywakemeanrecolineavg(i)=nanmean(activedaywakemeanreco(:,groupind(i):groupind(i+1)-1),2);
end

for i=group
    sleepboutlinenos(:,i)=nanmean(sleepboutnos(:,groupind(i):groupind(i+1)-1),2);
    sleepboutlineavg(:,i)=nanmean(sleepboutavg(:,groupind(i):groupind(i+1)-1),2);
    wakeboutlinenos(:,i)=nanmean(wakeboutnos(:,groupind(i):groupind(i+1)-1),2);
    wakeboutlineavg(:,i)=nanmean(wakeboutavg(:,groupind(i):groupind(i+1)-1),2);
end

    %Attempting to normalize sleep rebound to group means of baseline daytime
    %sleep AND the average difference in sleep lost the night of deprivation
warning('off','MATLAB:rankDeficientMatrix')
for i=1:animalnos
    normpercsleeprecovbin(i)=(sleeprecobin(i)-pulsesleeppredeplineavg(grouping(i)))/(nightsleeppredeplineavg(grouping(i))-nightsleepdep(i))*100;
end

    
for i=group
normpercsleeprecovbinlineavg(i)=nanmean(normpercsleeprecovbin(:,groupind(i):groupind(i+1)-1),2);
end
%% Plotting Sleep Data

%plot sleep propensity in 30min bins
daysLDvec=repelem(1:daysLD,4);
daylightx=[0,0,0.5,0.5]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfillx=repmat(daylightx,1,daysLD);
dayfillx=daysLDvec + dayfillx;
daylighty=[0,1,1,0]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfilly=repmat(daylighty,1,daysLD);
depfillx=[Depstart,Depstart,Depend,Depend];
depfilly=[0,1,1,0];
    if strcmpi(PULSE2,'Y') == 1
        pulse2fillx=[nightpulsestart,nightpulsestart,nightpulseend,nightpulseend];
        pulse2filly=[0,1,1,0];
    end
    
clear i j k
save('SleepDep_variables.mat', '-mat');
% Individual Activity and Binned Sleep Traces
    parfor k=1:animalnos
    tkindplot(k);
    end

% Line Averaged Activity and Binned Sleep Traces
    parfor k=group
    tkgroupplot(k);
    end
    
% Line Averaged Activity and Binned Sleep Traces with Deprivation
    parfor k=group
    tkdepplot(k);
    end

% if there are less than eight lines this will saveas them all on a single
% axis for visual comparison
if groupnumbers<=groupplotlim
figure    
  subplot(2,1,1)
    Ylim=max(max(activelineavg));
    fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
    hold on
    fill(depfillx,depfilly*Ylim,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1;
        fill(pulse2fillx,pulse2filly*Ylim,'r','FaceAlpha',0.5)    
        end
    h1 = plot(time,activelineavg,'LineWidth',2);
    ylabel('Activity (cnts)')
    if Ylim > 1
        ylim([0 Ylim])
    else
        ylim([0 1])
    end
    legend(h1,groupnames,'Location','northwest')
    title(strcat(foldername,' Activity and Sleep Profiles '));
    hold off
    subplot(2,1,2)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1;
        fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
        end
    plot(sleeptime,sleepproblineavg,'LineWidth',2);
% Use this code if you want to include markers for datapoints
%     h=plot(sleeptime,sleepproblineavg,'LineWidth',1,'Marker','s','MarkerSize',4);
%     set(h, {'MarkerFaceColor'}, get(h,'Color')); 
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
    savefig(gcf,strcat(foldername,' Locomotor and Sleep Trace Comparisons by line','.fig'));
    saveas(gcf,strcat(foldername,' Locomotor and Sleep Trace Comparisons by line','.pdf'),'pdf');
% and this is to plot sleep lost/recovered after deprivation.
figure
subplot(2,1,1)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    if strcmpi(DEP,'Y') ==1
    fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1
        fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
        end
    end
    h=plot(sleeptime,sleepproblineavg,'LineWidth',1);
%     set(h, {'MarkerFaceColor'}, get(h,'Color'));

    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
subplot(2,1,2)
    h1=plot(deptime,cumsleeplostperclineavg,'LineWidth',1);
%     set(h, {'MarkerFaceColor'}, get(h,'Color')); 
    xlabel('Time (days)')
    ylabel('Sleep Lost (%)')
    print(gcf,strcat(foldername,' Percent Sleep Lost Trace','.pdf'),'-dpdf');
    % and this is to plot sleep regained after deprivation.
figure
t=[0 2 4 6 8 10 12];
t2=t/24+(recoday+1);
subplot(2,1,1)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    if strcmpi(DEP,'Y') ==1
    fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
        if strcmpi(PULSE2,'Y') == 1
        fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
        end
    end
    h=plot(sleeptime,sleepproblineavg,'LineWidth',1);
%     set(h, {'MarkerFaceColor'}, get(h,'Color'));
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
subplot(2,1,2)
    h1=plot(deptime(sleepsr/2:sleepsr),cumsleeplostperclineavg(sleepsr/2:sleepsr,:)+100,'LineWidth',1);
%     set(h, {'MarkerFaceColor'}, get(h,'Color'));
    legend(h1,groupnames,'Location','northwest')
    xlabel('Time (hrs post deprivation)')
    ylabel('Sleep Recovered (%)')
    xticks(t2)
    xticklabels(t)
    ylim([0 50])
    print(gcf,strcat(foldername,' Percent Sleep Recovered Trace','.pdf'),'-dpdf');
close all
end

clear i j k
save('SleepDep_variables.mat', '-mat');
%% Extraneous Figure Plotting for Screening
if groupnumbers>20
    boxp='compact';
else
    boxp='traditional';
end

%Boxplots of LD and DD data
if strcmp(DD,'Y') == 1;
        positionLD=0.8:1:groupnumbers-0.2;
        positionDD=1.2:1:groupnumbers+0.2;
    %Total Sleep Time
figure
    boxplot(sleepLD,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','y');
    hold on
    boxplot(sleepDD,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'L:D Total Daily Sleep Time by line'))
    ylim([0 max([max(sleepLD) max(sleepDD)])+1])
        box_vars = findall(gca,'Tag','Box');
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Daily TST by line','.pdf'),'pdf')

    %Sleep Latency
    boxplot(latencyN(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','y');
    hold on
    boxplot(latencyN(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Sleep Latency by line'))
    ylim([0 max([max(latencyN(LDday,:)) max(latencyN(DDday,:))])+1])
        box_vars = findall(gca,'Tag','Box');
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Sleep Latency by line','.pdf'),'pdf')
    
    % Sleep Bout Count
    boxplot(wakeboutnos(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','y');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(wakeboutnos(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Nos (cnts)')
    title(strcat(foldername,'Sleep Bout Nos by line'))
    ylim([0 max([max(sleepboutnos(baseday,:)) max(sleepboutnos(depday,:)) max(sleepboutnos(recoday,:))])+ max([max(sleepboutnos(baseday,:)) max(sleepboutnos(depday,:)) max(sleepboutnos(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');        
        hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Nos of Sleep Bouts by line','.pdf'),'pdf')
    
    % Wake Bout Length
    boxplot(wakeboutavg(LDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionLD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','y');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(wakeboutavg(DDday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionDD,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Wake Bout Length (min)')
    title(strcat(foldername,'Wake Bout Length by line'))
    ylim([0 max([max(wakeboutavg(baseday,:)) max(wakeboutavg(depday,:)) max(wakeboutavg(recoday,:))])+ max([max(wakeboutavg(baseday,:)) max(wakeboutavg(depday,:)) max(wakeboutavg(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
                hLegend = legend(box_vars([groupnumbers+1,1]), {'L:D','D:D'},'location','best');
    saveas(gcf,strcat(foldername,' Wake Bout Length by line','.pdf'),'pdf') 
    
    if groupnumbers>10 && strcmp(DD,'Y') == 1;
    % Plotting wakefulness bout nos versus bout length
    gscatter(wakeboutlineavg(LDday,:),wakeboutlinenos(LDday,:),grouping,'y','o')
    hold on
    gscatter(wakeboutlineavg(DDday,:),wakeboutlinenos(DDday,:),grouping,'k','x')
    xlabel('Wake Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    title(strcat(foldername,'Wake Bout Length vs Number by line'))
    saveas(gcf,strcat(foldername,' Wake Bout Length Vs Nos by line','.pdf'),'pdf')
    
    gscatter(sleepboutlineavg(LDday,:),wakeboutlinenos(LDday,:),grouping,'y','o')
    hold on
    gscatter(sleepboutlineavg(DDday,:),wakeboutlinenos(DDday,:),grouping,'k','x')
    xlabel('Sleep Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    title(strcat(foldername,'Sleep Bout Length vs Number by line'))
    saveas(gcf,strcat(foldername,' Sleep Bout Length Vs Nos by line','.pdf'),'pdf')
    end
end

% Boxplots for Sleep Deprivation
if strcmp(DEP,'Y') == 1
        positionpredep=0.8:1:groupnumbers-0.2;
        positiondep=1:1:groupnumbers;
        positionreco=1.2:1:groupnumbers+0.2;
if groupnumbers < 26
        %Daily TST
figure
    boxplot(sleeppredep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(sleepdep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    set(gca,'XTickLabel',{' '})  % Erase xlabels   
    boxplot(sleepreco,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels   
    hold off     
% set(gca, 'XTickLabel',groupnames, 'XTick',1:numel(groupnames))
% set(gca,'XTickLabelRotation',45)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Daily TST'))
    ylim([0 max([max(sleeppredep) max(sleepdep) max(sleepreco)])*1.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    saveas(gcf,strcat(foldername,' Daily TST by line','.pdf'),'pdf')
    %Daytime TST
%     figure
    boxplot(daysleeppredep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(daysleepdep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(daysleepreco,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Daytime TST'))
    ylim([0 max([max(daysleeppredep) max(daysleepdep) max(daysleepreco)])+ max([max(daysleeppredep) max(daysleepdep) max(daysleepreco)])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    saveas(gcf,strcat(foldername,' Daytime TST by line','.pdf'),'pdf')
    %Nighttime TST
%     figure
    boxplot(nightsleeppredep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(nightsleepdep,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(nightsleepreco,grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,'Nighttime TST'))
    ylim([0 max([max(nightsleeppredep) max(nightsleepdep) max(nightsleepreco)])+ max([max(nightsleeppredep) max(nightsleepdep) max(nightsleepreco)])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    saveas(gcf,strcat(foldername,' Nighttime TST by line','.pdf'),'pdf')
 
% Sleep Latency
%     figure
    boxplot(latencyN(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(latencyN(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(latencyN(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Latency (min)')
    title(strcat(foldername,' Sleep Latency at Night by line'))
    ylim([0 max([max(latencyN(baseday,:)) max(latencyN(depday,:)) max(latencyN(recoday,:))])+ max([max(latencyN(baseday,:)) max(latencyN(depday,:)) max(latencyN(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    saveas(gcf,strcat(foldername,' Sleep Latency by line','.pdf'),'pdf')

% Sleep Latency after deprivation
%      figure    
    boxplot(latencyD(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'widths',0.15,...
        'jitter',0,...
        'colors','k'); 
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Latency (min)')
    title(strcat(foldername,' Latency to sleep after deprivation by line'))
    ylim([0 max(latencyD(recoday,:))*1.1])
    saveas(gcf,strcat(foldername,' Latency To Sleep After Deprivation by line','.pdf'),'pdf')

    
% Sleep Bout Count
%     figure
    boxplot(sleepboutnos(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(sleepboutnos(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(sleepboutnos(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Nos (cnts)')
    title(strcat(foldername,' Sleep Bout Nos by line'))
    ylim([0 max([max(sleepboutnos(baseday,:)) max(sleepboutnos(depday,:)) max(sleepboutnos(recoday,:))])+ max([max(sleepboutnos(baseday,:)) max(sleepboutnos(depday,:)) max(sleepboutnos(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    saveas(gcf,strcat(foldername,' Nos of Sleep Bouts by line','.pdf'),'pdf')
    
% Sleep Bout Length
%     figure
    boxplot(sleepboutavg(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(sleepboutavg(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(sleepboutavg(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Sleep Bout Length (min)')
    title(strcat(foldername,'Sleep Bout Length by line'))
    ylim([0 max([max(sleepboutavg(baseday,:)) max(sleepboutavg(depday,:)) max(sleepboutavg(recoday,:))])+ max([max(sleepboutavg(baseday,:)) max(sleepboutavg(depday,:)) max(sleepboutavg(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    saveas(gcf,strcat(foldername,' Sleep Bout Length by line','.pdf'),'pdf') 

% Wake Bout Count
%     figure
    boxplot(wakeboutnos(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(wakeboutnos(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(wakeboutnos(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Wake Bout Nos (cnts)')
    title(strcat(foldername,' Wake Bout Nos by line'))
    ylim([0 max([max(wakeboutnos(baseday,:)) max(wakeboutnos(depday,:)) max(wakeboutnos(recoday,:))])+ max([max(wakeboutnos(baseday,:)) max(wakeboutnos(depday,:)) max(wakeboutnos(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    saveas(gcf,strcat(foldername,' Nos of Wake Bouts by line','.pdf'),'pdf')
    
% Wake Bout Length
%     figure
    boxplot(wakeboutavg(baseday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionpredep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','b');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold on
    boxplot(wakeboutavg(depday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positiondep,...
        'widths',0.15,...
        'jitter',0,...
        'colors','r');
    boxplot(wakeboutavg(recoday,:),grouping(1:animalnos),...
        'plotstyle',boxp,...
        'positions',positionreco,...
        'widths',0.15,...
        'jitter',0,...
        'colors','g');
    set(gca,'XTickLabel',{' '})  % Erase xlabels  
    hold off
    xlabel('Line Nos')
    ylabel('Wake Bout Length (min)')
    title(strcat(foldername,' Wake Bout Length by line'))
    ylim([0 max([max(wakeboutavg(baseday,:)) max(wakeboutavg(depday,:)) max(wakeboutavg(recoday,:))])+ max([max(wakeboutavg(baseday,:)) max(wakeboutavg(depday,:)) max(wakeboutavg(recoday,:))])*0.1])
        box_vars = findall(gca,'Tag','Box');
        [~, ind] = sort(cellfun(@mean, get(box_vars, 'XData')));
        hLegend = legend(box_vars(ind(1:3)), {'Baseline','Deprivation','Recovery'},'location','best');
    saveas(gcf,strcat(foldername,' Wake Bout Length by line','.pdf'),'pdf')
end

% Sleep Recovery
% figure
boxplot(sleeprecobin,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Recovery Sleep'))
    ylim([0 max(sleeprecobin)*1.1])
    saveas(gcf,strcat(foldername,' Recovery Sleep by line','.pdf'),'pdf')
    
% Sleep Rebound
% figure
boxplot(sleepreboundbin,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Rebound Sleep'))
    ylim([min(sleepreboundbin)*1.1 max(sleepreboundbin)*1.1])
    saveas(gcf,strcat(foldername,' Rebound Sleep by line','.pdf'),'pdf')
    
% Percent Sleep Recovered
% figure
boxplot(percsleeprecovbin,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Rebound Sleep'))
    ylim([min(percsleeprecovbin)*1.1 max(percsleeprecovbin)*1.1])
    saveas(gcf,strcat(foldername,' Percent Sleep Recovered by line','.pdf'),'pdf')
    
% Normalized Percent Sleep Recovered
% figure
boxplot(normpercsleeprecovbin,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Rebound Sleep'))
    ylim([min(normpercsleeprecovbin)*1.1 max(normpercsleeprecovbin)*1.1])
    saveas(gcf,strcat(foldername,' Normalized Percent Sleep Recovered by line','.pdf'),'pdf')    
    
    % TST during second heat pulse
if strcmpi(PULSE2,'Y') == 1;
%   figure
    boxplot(nightsleeppulse,grouping(1:animalnos),'plotstyle',boxp)
    xlabel('Line Nos')
    ylabel('Total Sleep Time (min)')
    title(strcat(foldername,' Nighttime TST During 2nd Pulse'))
    ylim([min(nightsleeppulse)-abs(min(nightsleeppulse)*0.1) max(nightsleeppulse)*1.1])
    saveas(gcf,strcat(foldername,' TST during 2nd pulse by line','.pdf'),'pdf')
end
    

 %%   
if max(groupnumbers)>10 && strcmp(DD,'Y') == 1;
    % Plotting wakefulness bout nos versus bout length
%     figure
    gscatter(wakeboutlineavg(baseday,:),wakeboutlinenos(baseday,:),groupnumbers,'b','o')
    hold on
    gscatter(wakeboutlineavg(depday,:),wakeboutlinenos(depday,:),groupnumbers,'r','x')
    gscatter(wakeboutlineavg(recoday,:),wakeboutlinenos(recoday,:),groupnumbers,'g','+')
    hold off
    xlabel('Wake Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    title(strcat(foldername,' Wake Bout Length vs Number by line'))
    saveas(gcf,strcat(foldername,' Wake Bout Length Vs Nos by line','.pdf'),'pdf')
    
    % Plotting sleep bout nos versus bout length
%         figure
    gscatter(sleepboutlineavg(baseday,:),sleepboutlinenos(baseday,:),groupnumbers,'b','o')
    hold on
    gscatter(sleepboutlineavg(depday,:),sleepboutlinenos(depday,:),groupnumbers,'r','x')
    gscatter(sleepboutlineavg(recoday,:),sleepboutlinenos(recoday,:),groupnumbers,'g','+')
    hold off
    xlabel('Sleep Bout Length (min)')
    ylabel('Nos of Wake Bouts (cnts)')
    title(strcat(foldername,' Sleep Bout Length vs Number by line'))
    saveas(gcf,strcat(foldername,' Sleep Bout Length Vs Nos by line','.pdf'),'pdf')
end
end
%% Plot sleep probability in LD vs DD for all lines
if groupnumbers>10 && strcmp(DD,'Y') == 1;
    for i=group;
    sleepprobavg(:,i) = nanmean(sleepprob(groupind(i):groupind(i+1)-1));
    sleepLDavg(i) = nanmean(sleepLD(groupind(i):groupind(i+1)-1));
        if strcmp(DD,'Y') == 1;
        sleepDDavg(i) = nanmean(sleepDD(groupind(i):groupind(i+1)-1));
        end
    end

    if nosperline > 1
        if max(sleepLDavg)>max(sleepDDavg)
        X=0:1:max(sleepDDavg);
        Y=0:1:max(sleepDDavg);
        else
        X=0:1:max(sleepLDavg);
        Y=0:1:max(sleepLDavg); 
        end

%     figure
    scatter(sleepLDavg,sleepDDavg,'b');
    hold on
    plot(X,Y,'r')
    xlabel('Average Total Sleep Time (min) During LD')
    ylabel('Average Total Sleep Time (min) In Constant Darkness')
    title(strcat(foldername,' Total Daily Sleep Time by line'))
    ylim([0 max(sleepDDavg)+1])
    xlim([0 max(sleepLDavg)+1])
    savefig(strcat(foldername,' Daily TST LD vs DD Scatter Plot','.fig'))
    saveas(gcf,strcat(foldername,' Daily TST LD vs DD Scatter Plot','.pdf'),'pdf')
    end

    % Plot histograms for TST in LD and DD for screen
%     figure
    subplot(1,2,1)
    histfit(sleepLDavg,10);
    xlabel('Total Sleep Time')
    title('L:D')
    subplot(1,2,2)
    histfit(sleepDDavg,10);
    xlabel('Total Sleep Time')
    title('D:D')
    saveas(gcf,strcat(foldername,' Daily TST Histograms','.pdf'),'pdf')
end


if groupnumbers>10 && strcmp(DEP,'Y') == 1;
    % Plot histograms for TST during baseline, Deprivation, and Recovery   
    for i=group;
    sleeppredepavg(:,i) = nanmean(sleeppredep(groupind(i):groupind(i+1)-1));
    sleepdepavg(:,i) = nanmean(sleepdep(groupind(i):groupind(i+1)-1));
    sleeprecoavg(:,i) = nanmean(sleepreco(groupind(i):groupind(i+1)-1));
    end
    
        if sum(nosperline) > 1
        X=0:1:max([max(sleeppredepavg) max(sleepdepavg) max(sleeprecoavg)]);
        Y=0:1:max([max(sleeppredepavg) max(sleepdepavg) max(sleeprecoavg)]);
        Z=0:1:max([max(sleeppredepavg) max(sleepdepavg) max(sleeprecoavg)]);
        end
 % figure
    scatter3(sleeppredepavg,sleepdepavg,sleeprecoavg,5,'b','filled');
    view(40,35)
    hold on
    plot3(X,Y,Z,'r')
    hold off
    xlabel('Average Baseline TST(min)')
    ylabel('Average Deprivation TST(min)')
    zlabel('Average Recovery TST(min)')
    title('Total Daily Sleep Time by line')
    xlim([0 max(sleeppredepavg)*1.1])
    ylim([0 max(sleepdepavg)*1.1])
    zlim([0 max(sleeprecoavg)*1.1])
    savefig(strcat(foldername,' Daily TST Baseline vs Deprivation vs recovery Scatter Plot','.fig'))
    saveas(gcf,strcat(foldername,' Daily TST Baseline vs Deprivation vs recovery Scatter Plot','.pdf'),'pdf')
    
%     figure
    subplot(3,1,1)
    hist(sleeppredepavg,10);
    xlabel('Total Sleep Time')
    title('Baseline')
    subplot(3,1,2)
    hist(sleepdepavg,10);
    xlabel('Total Sleep Time')
    title('Deprivation')
    subplot(3,1,3)
    hist(sleeprecoavg,10);
    xlabel('Total Sleep Time')
    title('Recovery')
    saveas(gcf,strcat(foldername,' Total Daily Sleep Time Histograms','.pdf'),'pdf')
end


close all;
save('SleepDep_variables.mat', '-mat');
end
clear all;
end
