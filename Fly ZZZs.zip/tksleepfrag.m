function []=tksleepfrag(varargin)
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
load('SleepDep_variables.mat', '-mat');
% Calculating Sleep bout length and nos during for day/night comparisons
% (N.B. that this can be used to look at fragmentation mid phase as in
% Tabuchi et al. Cell 2018

%This is for baseline sleep fragmentation 
for i=1:animalnos
        tempwindday=find(wtsind{i}>=((baseday-1)*sr)+(midds*60/sam) & wtsind{i}<=((baseday-1)*sr)+(midde*60/sam));
        tempwindnight=find(wtsind{i}>=((baseday-1)*sr)+(midns*60/sam) & wtsind{i}<=((baseday-1)*sr)+(midne*60/sam));
        tempsindday=find(stwind{i}>=((baseday-1)*sr)+(midds*60/sam) & stwind{i}<=((baseday-1)*sr)+(midde*60/sam));
        tempsindnight=find(stwind{i}>=((baseday-1)*sr)+(midns*60/sam) & stwind{i}<=((baseday-1)*sr)+(midne*60/sam));
        tempwday=wtsind{i}(tempwindday);
        tempwnight=wtsind{i}(tempwindnight);
        tempsday=stwind{i}(tempsindday);
        tempsnight=stwind{i}(tempsindnight);
        %day
        if isempty(tempsindday)==1 && isempty(tempwindday)==1
            sleepboutsday{i}=sum(sleepdata(((baseday-1)*sr)+(midds*60/sam)+1:((baseday-1)*sr)+(midde*60/sam-1),i));
        elseif numel(tempsindday)==1 && numel(tempwindday)==1
            if tempsday<tempwday
            sleepboutsday{i}= [tempsday-(((baseday-1)*sr)+(midds*60/sam));((baseday-1)+(midde*60/sam))-tempwday]; %take stw-start & end-wts
            else
            sleepboutsday{i}=tempsday-tempwday; %stw-wts
            end
        elseif isempty(tempwindday)==1 && isempty(tempsindday)==0
            sleepboutsday{i}=tempsday-(((baseday-1)*sr)+(midde*60/sam)); %stw-start
        elseif isempty(tempwindday)==0 && isempty(tempsindday)==1        
            sleepboutsday{i}=(((baseday-1)*sr)+(midde*60/sam))-tempwday; %end-wts
        elseif isempty(tempwindday)==0 && isempty(tempsindday)==0
            if numel(tempwindday)>numel(tempsindday)
            sleepboutsday{i} = [tempsday;(((baseday-1)*sr)+(midde*60/sam))]-wtsind{i}(tempwindday);
            elseif numel(tempwindday)<numel(tempsindday)
            sleepboutsday{i} = tempsday-[(((baseday-1)*sr)+(midds*60/sam));tempwday];
            elseif numel(tempwindday)==numel(tempsindday)
                if tempwday(end)<tempsday(end)
                sleepboutsday{i} = tempsday-tempwday;
                else
                sleepboutsday{i} = [tempsday;((baseday-1)*sr)+(midde*60/sam)]-[((baseday-1)*sr)+(midds*60/sam);tempwday];    
                end
            end
        end
        %night
        if isempty(tempsindnight)==1 && isempty(tempwindnight)==1
            sleepboutsnight{i}=sum(sleepdata(((baseday-1)*sr)+(midns*60/sam):((baseday-1)*sr)+(midne*60/sam-1),i));
        elseif numel(tempwindnight)==1 && numel(tempsindnight)==1
            if tempsnight<tempwnight
            sleepboutsnight{i}= [tempsnight-(((baseday-1)*sr)+(midns*60/sam));((baseday-1)*sr)+(midne*60/sam-1)-tempwnight]; %take stw-start & end-wts
            else
            sleepboutsnight{i}=tempsnight-tempwnight; %stw-wts
            end
        elseif isempty(tempwindnight)==1 && isempty(tempsindnight)==0
            sleepboutsnight{i}=tempsnight-(((baseday-1)*sr)+(midns*60/sam)); %stw-start
        elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==1        
            sleepboutsnight{i}=((baseday-1)*sr)+(midne*60/sam-1)-tempwnight; %end-wts
        elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==0
            if numel(tempwindnight)>numel(tempsindnight)
            sleepboutsnight{i} = [tempsnight;((baseday-1)*sr)+(midne*60/sam-1)]-tempwnight;
            elseif numel(tempwindnight)<numel(tempsindnight)
            sleepboutsnight{i} = tempsnight-[(((baseday-1)*sr)+(midns*60/sam));tempwnight];
            elseif numel(tempwindnight)==numel(tempsindnight)
                if tempwnight(end)<tempsnight(end)
                sleepboutsnight{i} = tempsnight-tempwnight;
                else
                sleepboutsnight{i} = [tempsnight;((baseday-1)*sr)+(midne*60/sam)]-[((baseday-1)*sr)+(midns*60/sam);tempwnight];    
                end
            end
        end
%use this snippet of code to test for errors in bout analysis (so far so good)
if isempty(find(wakebouts{i}<0,1))==0 || isempty(find(sleepbouts{i}<0,1))==0
error('there is an error in the bout analysis please check code')
end
    sleepboutnosday(i)=numel(sleepboutsday{i});
            for k = 1:size(sleepboutnosday,1)
                for m=1:size(sleepboutnosday,2)
                    if isempty(sleepboutnosday(k,m)) || isnan(sleepboutnosday(k,m))
                    sleepboutnosnight(k,m) = 0;
                    elseif sum(sleepboutsday{i})==0
                    sleepboutnosday(k,m) = 0;
                    end
                end
            end
    sleepboutavgday(i)=nanmean(sleepboutsday{i}).*sam;

    sleepboutnosnight(i)=numel(sleepboutsnight{i});
            for k = 1:size(sleepboutnosnight,1)
                for m=1:size(sleepboutnosnight,2)
                    if isempty(sleepboutnosnight(k,m)) || isnan(sleepboutnosnight(k,m))
                    sleepboutnosnight(k,m) = 0;
                    elseif sum(sleepboutsnight{i})==0
                    sleepboutnosnight(k,m) = 0;
                    end
                end
            end
    sleepboutavgnight(i)=nanmean(sleepboutsnight{i}).*sam;

    sleepboutnosratio(i)=sleepboutnosday(i)/sleepboutnosnight(i); %bout nos
    sleepboutavgratio(i)=sleepboutavgday(i)/sleepboutavgnight(i); %bout length
end

%This is for activation and rebound
if strcmpi(DEP,'Y') == 1
clear tempwday tempwnight tempsday tempsnight;
    
for i=1:animalnos
        tempwindday=find(wtsind{i}>=((baseday-1)*sr)+(midrs*60/sam) & wtsind{i}<=((baseday-1)*sr)+(midre*60/sam));
        tempwindnight=find(wtsind{i}>=((baseday-1)*sr)+(midas*60/sam) & wtsind{i}<=((baseday-1)*sr)+(midae*60/sam));
        tempsindday=find(stwind{i}>=((baseday-1)*sr)+(midrs*60/sam) & stwind{i}<=((baseday-1)*sr)+(midre*60/sam));
        tempsindnight=find(stwind{i}>=((baseday-1)*sr)+(midas*60/sam) & stwind{i}<=((baseday-1)*sr)+(midae*60/sam));
        tempwday=wtsind{i}(tempwindday);
        tempwnight=wtsind{i}(tempwindnight);
        tempsday=stwind{i}(tempsindday);
        tempsnight=stwind{i}(tempsindnight);
        %Rebound
        if isempty(tempsindday)==1 && isempty(tempwindday)==1
            sleepboutsrebound{1,i}=sum(sleepdata(((baseday-1)*sr)+(midrs*60/sam):((baseday-1)*sr)+(midre*60/sam-1),i));
            sleepboutsrebound{2,i}=1;
        elseif numel(tempwindday)==1 && numel(tempsindday)==1
            if tempsday<tempwday
            sleepboutsrebound{1,i}= [tempsday-(((baseday-1)*sr)+(midrs*60/sam));(((baseday-1)*sr)+(midre*60/sam))-tempwday]; %take stw-start & end-wts
            sleepboutsrebound{2,i}=2;
            else
            sleepboutsrebound{1,i}=tempsday-tempwday; %stw-wts
            sleepboutsrebound{2,i}=3;
            end
        elseif isempty(tempwindday)==1 && isempty(tempsindday)==0
            sleepboutsrebound{1,i}=tempsday-(((baseday-1)*sr)+(midrs*60/sam)); %stw-start
            sleepboutsrebound{2,i}=4;
        elseif isempty(tempwindday)==0 && isempty(tempsindday)==1        
            sleepboutsrebound{1,i}=((baseday-1)*sr)+(midre*60/sam)-tempwday; %end-wts
            sleepboutsrebound{2,i}=5;
        elseif isempty(tempwindday)==0 && isempty(tempsindday)==0
            if numel(tempwindday)>numel(tempsindday)
            sleepboutsrebound{1,i} = [tempsday;((baseday-1)*sr)+(midre*60/sam)]-tempwday;
            sleepboutsrebound{2,i}=6;
            elseif numel(tempwindday)<numel(tempsindday)
            sleepboutsrebound{1,i} = tempsday-[((baseday-1)*sr)+(midrs*60/sam);tempwday];
            sleepboutsrebound{2,i}=7;
            elseif numel(tempwindday)==numel(tempsindday)
                if tempwday(end)<tempsday(end)
                sleepboutsrebound{1,i} = tempsday-tempwday;
                sleepboutsrebound{2,i}=8;
                else
                sleepboutsrebound{1,i} = [tempsday;((baseday-1)*sr)+(midre*60/sam)]-[((baseday-1)*sr)+(midrs*60/sam);tempwday];    
                sleepboutsrebound{2,i}=9;
                end
            end
        end
        %Activation
        if isempty(tempsindnight)==1 && isempty(tempwindnight)==1
            sleepboutsactivation{1,i}=sum(sleepdata(((baseday-1)*sr)+(midas*60/sam):((baseday-1)*sr)+(midae*60/sam-1),i));
            sleepboutsactivation{2,i}=1;
        elseif numel(tempwindnight)==1 && numel(tempsindnight)==1
            if tempsnight<tempwnight
            sleepboutsactivation{1,i}= [tempsnight-(((baseday-1)*sr)+(midas*60/sam));(((baseday-1)*sr)+(midae*60/sam))-tempwnight]; %take stw-start & end-wts
            sleepboutsactivation{2,i}=2;
            else
            sleepboutsactivation{1,i}=tempsnight-tempwnight; %stw-wts
            sleepboutsactivation{2,i}=3;
            end
        elseif isempty(tempwindnight)==1 && isempty(tempsindnight)==0
            sleepboutsactivation{1,i}=tempsnight-(((baseday-1)*sr)+(midas*60/sam)); %stw-start
            sleepboutsactivation{2,i}=4;
        elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==1        
            sleepboutsactivation{1,i}=(((baseday-1)*sr)+(midae*60/sam))-tempwnight; %end-wts
            sleepboutsactivation{2,i}=5;
        elseif isempty(tempwindnight)==0 && isempty(tempsindnight)==0
            if numel(tempwindnight)>numel(tempsindnight)
            sleepboutsactivation{1,i} = [tempsnight;((baseday-1)*sr)+(midae*60/sam)]-tempwnight;
            sleepboutsactivation{2,i}=6;
            elseif numel(tempwindnight)<numel(tempsindnight)
            sleepboutsactivation{1,i} = tempsnight-[((baseday-1)*sr)+(midas*60/sam);tempwnight];
            sleepboutsactivation{2,i}=7;
            elseif numel(tempwindnight)==numel(tempsindnight)
                if tempwnight(end)<tempsnight(end)
                sleepboutsactivation{1,i} = tempsnight-tempwnight;
                sleepboutsactivation{2,i}=8;
                else
                sleepboutsactivation{1,i} = [tempsnight;((baseday-1)*sr)+(midae*60/sam)]-[((baseday-1)*sr)+(midas*60/sam);tempwnight];
                sleepboutsactivation{2,i}=9;
                end 
            end
        end
%use this snippet of code to test for errors in bout analysis (so far so good)
    if isempty(find(wakebouts{i}<0,1))==0 || isempty(find(sleepbouts{i}<0,1))==0
    error('there is an error in the bout analysis please check code')
    end

    sleepboutnosrebound(i)=numel(sleepboutsrebound{1,i});
        
    for k = 1:size(sleepboutnosrebound,1)
        for m=1:size(sleepboutnosrebound,2)
            if isempty(sleepboutnosrebound(k,m)) || isnan(sleepboutnosrebound(k,m))
                sleepboutnosrebound(k,m) = 0;
            elseif sum(sleepboutsrebound{1,i})==0
                sleepboutnosrebound(k,m) = 0;
            end
        end
    end
    sleepboutavgrebound(i)=nanmean(sleepboutsrebound{1,i}).*sam;
        
    sleepboutnosactivation(i)=numel(sleepboutsactivation{1,i});
    for k = 1:size(sleepboutnosactivation,1)
        for m=1:size(sleepboutnosactivation,2)
            if isempty(sleepboutnosactivation(k,m)) || isnan(sleepboutnosactivation(k,m))
                sleepboutnosnight(k,m) = 0;
            elseif sum(sleepboutsactivation{1,i})==0
            sleepboutnosactivation(k,m) = 0;
            end
        end
    end
    sleepboutavgactivation(i)=nanmean(sleepboutsactivation{1,i}).*sam;
        
end
end

sleepboutnosday(deadind)=NaN;
sleepboutnosnight(deadind)=NaN;
sleepboutavgday(deadind)=NaN;
sleepboutavgnight(deadind)=NaN;
sleepboutnosratio(deadind)=NaN;
sleepboutavgratio(deadind)=NaN;
if strcmpi(DEP,'Y') == 1
sleepboutnosrebound(deadind)=NaN;
sleepboutavgrebound(deadind)=NaN;
sleepboutnosactivation(deadind)=NaN;
sleepboutavgactivation(deadind)=NaN;
end
 save('frag_variables.mat', '-mat');