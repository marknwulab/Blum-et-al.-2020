%Run and plot sleep data from Trikinetics locomotor monitors (does not
%remove dead animals)

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function []=tksleeptrace(varargin)
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');

%  preallocating for speed
dlen=size(datatrim,1);
slen=dlen/sleepbin;

% Generates sliding window to define lack of activity as sleep
sleepsum=zeros(size(datatrim,1)-sleepdef,animalnos);
sleepsumend=ones(sleepdef,animalnos);
for i=1:animalnos;
   for j=1:size(datatrim,1)-sleepdef;
    sleepsum(j,i)=sum(datatrim(j:(j-1)+sleepdef,i));
   end
end
sleepsum=[sleepsum;sleepsumend]; %just padding the last five minutes with no sleep and very low activity

%locate all the sleep epochs and generates sleepdata logical matrix
%locate all the sleep epochs and generates sleepdata logical matrix
sleepind=find(~sleepsum); %locates all the sleep epochs
sleepdata=zeros(size(datatrim));
for i=1:sleepdef
sleepdata(sleepind(5:end)+1-i)=1; %#ok<FNDSB> %
end
active=datatrim;
if strcmp(ALL,'Y') == 1
sleepdata(:,deadind)=NaN; %Remove all dead animals from sleep analysis
active(:,deadind)=NaN; %Remove all dead animals from activity analysis
end

% Calculating the final group sizes after accounting for dead animals and
% those that lack appropriate deprivation
groups=ones(1,animalnos);
groupsind=isnan(sleepdata(1,:));
groups=groups.*~groupsind;
groupsize=zeros(1,groupnumbers);
for i=group
groupsize(i)=sum(groups(groupind(i):groupind(i+1)-1));
end

% finding sleep probability per bin
sleeptime=((1:size(sleepdata,1)/sleepbin)/sleepsr)+1; %generates a timeseries for sleepbinning
sleepprob=zeros(slen,animalnos);
sb=sleepbin;
parfor i=1:animalnos;
   sd=sleepdata(:,i)
   for j=1:slen;
   sbtrim=(sb*j)-sb+1:sb*j;
   sleepprob(j,i)=sum(sd(sbtrim))/sb*100;
   end
end

%Generating group averages for all parameters after removing flies based on
%deprivation threshold
for i=group
    activelineavg(:,i)=nanmean(active(:,groupind(i):groupind(i+1)-1),2);
    sleepproblineavg(:,i)=nanmean(sleepprob(:,groupind(i):groupind(i+1)-1),2);
end

% Calculating the final group sizes after accounting for dead animals and
% those that lack appropriate deprivation
groupsind=isnan(sleepdata(1,:));
groups=ones(1,animalnos).*~groupsind;
temp=zeros(1,animalnos); temp(deadind)=1;deadgroups=temp;
    if exist('depind')==0
    depgroups=ones(1,animalnos);   
    elseif isempty(grouptype)==0
    temp=zeros(1,animalnos);temp(depind)=1;depgroups=temp;
    else
    depgroups=ones(1,animalnos);
    end
groupsize=zeros(1,groupnumbers);deadsize=zeros(1,groupnumbers);depsize=zeros(1,groupnumbers);
    for i=group
    groupsize(i)=sum(groups(groupind(i):groupind(i+1)-1));
    deadsize(i)=sum(deadgroups(groupind(i):groupind(i+1)-1));
    depsize(i)=sum(depgroups(groupind(i):groupind(i+1)-1));
    end

%plot sleep propensity in 30min bins
daysLDvec=repelem(1:daysLD,4);
daylightx=[0,0,0.5,0.5]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfillx=repmat(daylightx,1,daysLD);
dayfillx=daysLDvec + dayfillx;
daylighty=[0,1,1,0]; %for plotting light bars to show LD, simply repeat the pattern as necessary for multiple days.
dayfilly=repmat(daylighty,1,daysLD);
if strcmpi(DEP,'Y') == 1;
depfillx=[Depstart,Depstart,Depend,Depend];
depfilly=[0,1,1,0];
    if strcmpi(PULSE2,'Y') == 1;
        pulse2fillx=[nightpulsestart,nightpulsestart,nightpulseend,nightpulseend];
        pulse2filly=[0,1,1,0];
    end
end

save('SleepDep_variables.mat', '-mat');


% Individual Activity and Binned Sleep Traces
for i=1:animalnos;
    if groupsind(i)==0
        subplot(2,1,1)
        Ylim=max(active(:,i));
        fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
        hold on
        if strcmpi(DEP,'Y') == 1;
                fill(depfillx,depfilly*Ylim,'r','FaceAlpha',0.5)
                    if strcmpi(PULSE2,'Y') == 1;
                    fill(pulse2fillx,pulse2filly*Ylim,'r','FaceAlpha',0.5)    
                    end
        end
        plot(time,active(:,i),'k','LineWidth',2);
        ylabel('Activity (cnts)')
        if Ylim > 1
            ylim([0 Ylim])
        else
            ylim([0 1])
        end
        title(strcat('Activity and Sleep Profiles ',textfiles(i).name));
        hold off
        subplot(2,1,2)
        fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
        hold on
        if strcmpi(DEP,'Y') == 1;
                fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
                    if strcmpi(PULSE2,'Y') == 1;
                    fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
                    end
        end
        plot(sleeptime,sleepprob(:,i),'k','LineWidth',2);
        xlabel('Time (days)')
        ylabel('Sleep Probability (%)')
        hold off
        print(gcf,strcat(textfiles(i).name,' Locomotor and Sleep Trace','.pdf'),'-dpdf');
    end
end

% Line Averaged Activity and Binned Sleep Traces
for i=group
    subplot(2,1,1)
    Ylim=max(activelineavg(:,i));
    fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
    hold on
    if strcmpi(DEP,'Y') == 1;
        fill(depfillx,depfilly*Ylim,'r','FaceAlpha',0.5)
            if strcmpi(PULSE2,'Y') == 1;
            fill(pulse2fillx,pulse2filly*Ylim,'r','FaceAlpha',0.5)    
            end
    end
    plot(time,activelineavg(:,i),'k','LineWidth',2);
    ylabel('Activity (cnts)')
    if Ylim > 1
        ylim([0 Ylim])
    else
        ylim([0 1])
    end
    title(strcat(num2str(group(i)),' Activity and Sleep Profiles'));
    hold off
    subplot(2,1,2)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    if strcmpi(DEP,'Y') == 1;
        fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
            if strcmpi(PULSE2,'Y') == 1;
            fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
            end
    end
    plot(sleeptime,sleepproblineavg(:,i),'k','LineWidth',2);
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
    print(gcf,strcat('Line Nos. ',num2str(group(i)),' Locomotor and Sleep Trace','.pdf'),'-dpdf');
end

% if there are less than eight lines this will print them all on a single
% axis for visual comparison
if groupnumbers<=8
 for i=group
     lgnd{i}=textfilenames{groupind(i)}(1:end-13);
 end
% figure    
  subplot(2,1,1)
    Ylim=max(max(activelineavg));
    fill(dayfillx,dayfilly*Ylim,'y','FaceAlpha',0.5)
    hold on
    if strcmpi(DEP,'Y') == 1;
        fill(depfillx,depfilly*Ylim,'r','FaceAlpha',0.5)
            if strcmpi(PULSE2,'Y') == 1;
            fill(pulse2fillx,pulse2filly*Ylim,'r','FaceAlpha',0.5)    
            end
    end
    h1 = plot(time,activelineavg,'LineWidth',1);
    ylabel('Activity (cnts)')
    if Ylim > 1
        ylim([0 Ylim])
    else
        ylim([0 1])
    end
    legend(h1,lgnd,'Location','northwest')
    title(strcat(foldername,' Activity and Sleep Profiles '));
    hold off
    subplot(2,1,2)
    fill(dayfillx,dayfilly*100,'y','FaceAlpha',0.5)
    hold on
    if strcmpi(DEP,'Y') == 1;
        fill(depfillx,depfilly*100,'r','FaceAlpha',0.5)
            if strcmpi(PULSE2,'Y') == 1;
            fill(pulse2fillx,pulse2filly*100,'r','FaceAlpha',0.5)    
            end
    end
    plot(sleeptime,sleepproblineavg,'LineWidth',1);
    xlabel('Time (days)')
    ylabel('Sleep Probability (%)')
    hold off
    print(gcf,strcat(foldername,' Locomotor and Sleep Trace Visualization Comparison','.pdf'),'-dpdf');
end

