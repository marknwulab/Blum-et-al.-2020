%Take outputs from tksleepdep and perform z-scoring, outlier detection,
%multivariate analysis, PCA, and clustering analysis for screening purposes

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Mark Wu Lab, Johns Hopkins University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Mark Wu Lab, Rangos Bldg, Johns Hopkins University,             %%
% Baltimore, MD, 21231 USA                                        %%
% Email: marknwu@jhmi.edu                                         %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=tkzscore(varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Variables.mat', '-mat');
load('file_variables.mat', '-mat');
load('SleepDep_variables.mat', '-mat');

% Sets the cutoff for outliers (in Std Deviations)
outlier=-2.25;

%% Z-score all data
%Generate matrices to handle key output variables
varnames={'Bline TST','Bline Day TST','Bline Night TST','Post-Pulse TST',...
    'Post-Pulse Day TST','Post-Pulse Night TST','Recovery TST','Recovery Day TST',...
    'Recovery Night TST','Recovery Sleep','Sleep Rebound','Overnight Pulse','Sleep Latency','Rebound Latency'};
varcell=[sleeppredep;daysleeppredep;nightsleeppredep;sleepdep;...
    daysleepdep;nightsleepdep;sleepreco;daysleepreco;...
    nightsleepreco;sleeprecobin;sleepreboundbin;nightsleeppulse;latencyN(baseday,:);reblat];

% find avg of each variable by line
for i=1:length(varnames)
    for j=1:groupnumbers
    groupvar(i,j)= nanmean(varcell(i,find(grouping == j)));
    end
end

%Calculating Z-score to identify outliers
for k=1:length(varnames);
    temp=groupvar(k,:);
    Zmu(k,:)=nanmean(temp);
    Zsigma(k,:)=nanstd(temp);
    Zed(k,:) = (temp - nanmean(temp))/nanstd(temp);
    clear temp
end

%Find outliers
for l=1:length(varnames)
Zedind{l}=find(Zed(l,:) <= outlier);
Zedsig{l}=groupvar(l,Zedind{l});
Zedhits{l}=groupnames(Zedind{l});
    if isempty(Zedhits{l})== 1;
    Zedhits{l}=0;
    end
end

for m=1:length(varnames)
maxgroupvar=max(groupvar(m,:));
mingroupvar=min(groupvar(m,:));
% histogram for all lines showing outliers (as defined by SD threshold set above).
xbins=mingroupvar:20:maxgroupvar;
[cnt{m},cntr{m}]=hist(groupvar(m,:),xbins);
[cntsig{m},cntrsig{m}]=hist(Zedsig{m},xbins);
% figure
bar(cntr{m},cnt{m}, 'facecolor', 'k'), hold on
hold on
bar(cntrsig{m},cntsig{m},'facecolor','r')
xlabel(varnames{m})
ylabel('Instances')
title('Sleep Parameter Histogram')
hold off
print(strcat(foldername,' Sleep Parameter Histogram_',varnames{m},'.pdf'),'-dpdf')
end

close all;
save('SleepDep_zscores.mat', '-mat');

%% need to add a way for the significant lines (group number and phenotype)
% to be added to the existing excel sheet or can be exported into it's own
% sheet.
